// src/app/categories/[category]/page.tsx - 특정 카테고리의 포스트들을 보여주는 페이지

'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import {
  Container,
  Typography,
  Box,
  Breadcrumbs,
  Link as MuiLink,
  Chip,
  CircularProgress,
} from '@mui/material';
import {
  Home as HomeIcon,
  Category as CategoryIcon,
  Article as ArticleIcon,
} from '@mui/icons-material';
import Link from 'next/link';
import Layout from '@/components/Layout';
import PostList from '@/components/PostList';
import { BlogPost, CategoryCount } from '@/types/blog';

/**
 * 특정 카테고리 페이지 컴포넌트
 * URL의 category 파라미터에 해당하는 카테고리의 모든 포스트를 표시
 */
export default function CategoryDetailPage() {
  const params = useParams();
  const decodedCategory = decodeURIComponent(params.category as string);
  
  // 상태 관리
  const [categoryPosts, setCategoryPosts] = useState<BlogPost[]>([]);
  const [categories, setCategories] = useState<CategoryCount[]>([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  // 데이터 로딩
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        
        // API를 통해 카테고리 포스트와 전체 카테고리 목록 가져오기
        const [postsResponse, categoriesResponse] = await Promise.all([
          fetch(`/api/search?category=${encodeURIComponent(decodedCategory)}`),
          fetch('/api/categories'),
        ]);

        const [postsData, categoriesData] = await Promise.all([
          postsResponse.json(),
          categoriesResponse.json(),
        ]);

        if (postsData.success) {
          setCategoryPosts(postsData.data);
          
          // 포스트가 없고 카테고리도 존재하지 않으면 404
          if (postsData.data.length === 0 && categoriesData.success) {
            const categoryExists = categoriesData.data.some((cat: CategoryCount) => cat.category === decodedCategory);
            if (!categoryExists) {
              setNotFound(true);
              return;
            }
          }
        }

        if (categoriesData.success) {
          setCategories(categoriesData.data);
        }
        
      } catch (error) {
        console.error('Error loading category data:', error);
        setNotFound(true);
      } finally {
        setLoading(false);
      }
    };

    if (decodedCategory) {
      loadData();
    }
  }, [decodedCategory]);

  // 404 상태일 때
  if (notFound) {
    return (
      <Layout>
        <Container maxWidth="lg" sx={{ py: 8, textAlign: 'center' }}>
          <Typography variant="h4" component="h1" sx={{ mb: 2 }}>
            카테고리를 찾을 수 없습니다
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
            요청하신 "{decodedCategory}" 카테고리가 존재하지 않습니다.
          </Typography>
          <Link href="/categories">
            <Typography component="span" sx={{ color: 'primary.main', textDecoration: 'underline' }}>
              모든 카테고리 보기 →
            </Typography>
          </Link>
        </Container>
      </Layout>
    );
  }

  return (
    <Layout>
      <Container maxWidth="lg" sx={{ py: 4 }}>
        {/* 로딩 상태 */}
        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
            <CircularProgress size={60} />
          </Box>
        )}

        {!loading && (
          <>
            {/* 브레드크럼 네비게이션 */}
            <Box sx={{ mb: 4 }}>
              <Breadcrumbs aria-label="breadcrumb" separator="›">
                <MuiLink
                  component={Link}
                  href="/"
                  color="inherit"
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    '&:hover': {
                      textDecoration: 'underline',
                    },
                  }}
                >
                  <HomeIcon sx={{ mr: 0.5, fontSize: 20 }} />
                  홈
                </MuiLink>
                <MuiLink
                  component={Link}
                  href="/categories"
                  color="inherit"
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    textDecoration: 'none',
                    '&:hover': {
                      textDecoration: 'underline',
                    },
                  }}
                >
                  <CategoryIcon sx={{ mr: 0.5, fontSize: 20 }} />
                  카테고리
                </MuiLink>
                <Typography
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    color: 'text.primary',
                  }}
                >
                  {decodedCategory}
                </Typography>
              </Breadcrumbs>
            </Box>

            {/* 페이지 헤더 */}
            <Box sx={{ textAlign: 'center', mb: 6 }}>
              <Typography
                variant="h3"
                component="h1"
                sx={{
                  fontWeight: 700,
                  mb: 2,
                  fontSize: { xs: '2rem', sm: '2.5rem', md: '3rem' },
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 2,
                  flexWrap: 'wrap',
                }}
              >
                <CategoryIcon sx={{ fontSize: { xs: 40, md: 60 }, color: 'primary.main' }} />
                {decodedCategory}
              </Typography>
              
              <Typography
                variant="h6"
                component="p"
                color="text.secondary"
                sx={{
                  fontWeight: 400,
                  maxWidth: 600,
                  margin: '0 auto',
                  lineHeight: 1.6,
                  mb: 3,
                }}
              >
                {decodedCategory} 카테고리의 모든 포스트를 확인해보세요. <br />
                총 <strong>{categoryPosts.length}개</strong>의 포스트가 있습니다.
              </Typography>

              <Chip
                icon={<ArticleIcon />}
                label={`${categoryPosts.length}개의 포스트`}
                color="primary"
                variant="filled"
                sx={{
                  fontWeight: 600,
                  fontSize: '1rem',
                  height: 40,
                  px: 2,
                }}
              />
            </Box>

            {/* 포스트 목록 */}
            <PostList
              posts={categoryPosts}
              loading={false}
              emptyMessage={`${decodedCategory} 카테고리에는 아직 포스트가 없습니다.`}
              showFeatured={true}
            />

            {/* 관련 카테고리 추천 */}
            {categories.length > 1 && (
              <Box sx={{ mt: 8, p: 4, bgcolor: 'background.paper', borderRadius: 2, border: 1, borderColor: 'divider' }}>
                <Typography variant="h6" component="h3" sx={{ mb: 3, fontWeight: 600, textAlign: 'center' }}>
                  다른 카테고리도 둘러보세요
                </Typography>
                
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, justifyContent: 'center' }}>
                  {categories
                    .filter(cat => cat.category !== decodedCategory)
                    .slice(0, 8)
                    .map((categoryData) => (
                      <Chip
                        key={categoryData.category}
                        label={`${categoryData.category} (${categoryData.count})`}
                        component={Link}
                        href={`/categories/${encodeURIComponent(categoryData.category)}`}
                        clickable
                        variant="outlined"
                        color="secondary"
                        sx={{
                          fontWeight: 500,
                          '&:hover': {
                            bgcolor: 'secondary.main',
                            color: 'secondary.contrastText',
                          },
                          transition: 'all 0.2s ease-in-out',
                        }}
                      />
                    ))}
                </Box>

                <Box sx={{ textAlign: 'center', mt: 3 }}>
                  <MuiLink
                    component={Link}
                    href="/categories"
                    sx={{
                      textDecoration: 'none',
                      color: 'primary.main',
                      fontWeight: 600,
                      '&:hover': {
                        textDecoration: 'underline',
                      },
                    }}
                  >
                    모든 카테고리 보기 →
                  </MuiLink>
                </Box>
              </Box>
            )}

            {/* 검색 제안 */}
            <Box sx={{ textAlign: 'center', mt: 6, p: 4, bgcolor: 'grey.50', borderRadius: 2 }}>
              <Typography variant="h6" component="h3" sx={{ mb: 2, fontWeight: 600 }}>
                원하는 내용을 찾지 못하셨나요?
              </Typography>
              <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
                키워드 검색이나 태그 필터를 사용해 더 정확한 포스트를 찾아보세요.
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
                <MuiLink
                  component={Link}
                  href={`/search?category=${encodeURIComponent(decodedCategory)}`}
                  sx={{
                    textDecoration: 'none',
                    color: 'primary.main',
                    fontWeight: 600,
                    '&:hover': {
                      textDecoration: 'underline',
                    },
                  }}
                >
                  {decodedCategory} 검색
                </MuiLink>
                <span style={{ color: '#666' }}>•</span>
                <MuiLink
                  component={Link}
                  href="/search"
                  sx={{
                    textDecoration: 'none',
                    color: 'primary.main',
                    fontWeight: 600,
                    '&:hover': {
                      textDecoration: 'underline',
                    },
                  }}
                >
                  전체 검색
                </MuiLink>
                <span style={{ color: '#666' }}>•</span>
                <MuiLink
                  component={Link}
                  href="/posts"
                  sx={{
                    textDecoration: 'none',
                    color: 'primary.main',
                    fontWeight: 600,
                    '&:hover': {
                      textDecoration: 'underline',
                    },
                  }}
                >
                  모든 포스트
                </MuiLink>
              </Box>
            </Box>
          </>
        )}
      </Container>
    </Layout>
  );
}