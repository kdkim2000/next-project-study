// src/app/categories/page.tsx - 모든 카테고리를 보여주는 페이지

import React from 'react';
import {
  Container,
  Typography,
  Box,
  Breadcrumbs,
  Link as MuiLink,
  Grid,
  Paper,
  Chip,
} from '@mui/material';
import {
  Home as HomeIcon,
  Category as CategoryIcon,
  Article as ArticleIcon,
} from '@mui/icons-material';
import Link from 'next/link';
import Layout from '@/components/Layout';
import { getCategoriesWithCount } from '@/lib/blog';

// 메타데이터 설정 (SEO 최적화)
export const metadata = {
  title: '카테고리 | Developer\'s Blog',
  description: '개발 블로그의 모든 카테고리를 확인하고 관심 있는 주제의 포스트를 찾아보세요.',
  keywords: '카테고리, 개발, 프로그래밍, React, Next.js, TypeScript, 웹개발',
};

/**
 * 카테고리 목록 페이지 컴포넌트
 * 모든 카테고리와 각 카테고리별 포스트 수를 표시하는 페이지
 */
export default async function CategoriesPage() {
  // 카테고리별 포스트 개수 데이터 가져오기
  const categories = await getCategoriesWithCount();

  return (
    <Layout>
      <Container maxWidth="lg" sx={{ py: 4 }}>
        {/* 브레드크럼 네비게이션 */}
        <Box sx={{ mb: 4 }}>
          <Breadcrumbs aria-label="breadcrumb" separator="›">
            <MuiLink
              component={Link}
              href="/"
              color="inherit"
              sx={{
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                '&:hover': {
                  textDecoration: 'underline',
                },
              }}
            >
              <HomeIcon sx={{ mr: 0.5, fontSize: 20 }} />
              홈
            </MuiLink>
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                color: 'text.primary',
              }}
            >
              <CategoryIcon sx={{ mr: 0.5, fontSize: 20 }} />
              카테고리
            </Box>
          </Breadcrumbs>
        </Box>

        {/* 페이지 헤더 */}
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Typography
            variant="h3"
            component="h1"
            sx={{
              fontWeight: 700,
              mb: 2,
              fontSize: { xs: '2rem', sm: '2.5rem', md: '3rem' },
            }}
          >
            모든 카테고리
          </Typography>
          
          <Typography
            variant="h6"
            component="p"
            color="text.secondary"
            sx={{
              fontWeight: 400,
              maxWidth: 600,
              margin: '0 auto',
              lineHeight: 1.6,
            }}
          >
            관심 있는 주제를 선택하여 관련 포스트들을 탐색해보세요. <br />
            현재 총 <strong>{categories.length}개</strong>의 카테고리가 있습니다.
          </Typography>
        </Box>

        {/* 카테고리 통계 */}
        {categories.length > 0 && (
          <Box sx={{ textAlign: 'center', mb: 6 }}>
            <Typography variant="h4" component="div" sx={{ fontWeight: 700, color: 'primary.main', mb: 1 }}>
              {categories.reduce((sum, cat) => sum + cat.count, 0)}
            </Typography>
            <Typography variant="body1" color="text.secondary">
              전체 포스트 수
            </Typography>
          </Box>
        )}

        {/* 카테고리가 없는 경우 */}
        {categories.length === 0 && (
          <Box sx={{ textAlign: 'center', py: 8 }}>
            <CategoryIcon sx={{ fontSize: 80, color: 'text.disabled', mb: 2 }} />
            <Typography variant="h5" component="h2" sx={{ mb: 2, color: 'text.secondary' }}>
              아직 카테고리가 없습니다
            </Typography>
            <Typography variant="body1" color="text.secondary">
              첫 번째 포스트를 작성하여 카테고리를 만들어보세요!
            </Typography>
          </Box>
        )}

        {/* 카테고리 그리드 */}
        {categories.length > 0 && (
          <Grid container spacing={3}>
            {categories.map((categoryData, index) => (
              <Grid item xs={12} sm={6} md={4} lg={3} key={categoryData.category}>
                <Paper
                  component={Link}
                  href={`/categories/${encodeURIComponent(categoryData.category)}`}
                  elevation={2}
                  sx={{
                    p: 3,
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    textAlign: 'center',
                    textDecoration: 'none',
                    color: 'inherit',
                    position: 'relative',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease-in-out',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: 8,
                      bgcolor: 'primary.main',
                      color: 'primary.contrastText',
                      '& .category-icon': {
                        color: 'primary.contrastText',
                      },
                      '& .post-count-chip': {
                        bgcolor: 'primary.contrastText',
                        color: 'primary.main',
                      },
                    },
                  }}
                >
                  {/* 카테고리 아이콘 */}
                  <CategoryIcon 
                    className="category-icon"
                    sx={{ 
                      fontSize: 48, 
                      color: 'primary.main', 
                      mb: 2,
                      transition: 'color 0.3s ease-in-out',
                    }} 
                  />

                  {/* 카테고리 이름 */}
                  <Typography
                    variant="h6"
                    component="h3"
                    sx={{
                      fontWeight: 600,
                      mb: 2,
                      wordBreak: 'break-word',
                      lineHeight: 1.3,
                    }}
                  >
                    {categoryData.category}
                  </Typography>

                  {/* 포스트 개수 */}
                  <Chip
                    className="post-count-chip"
                    icon={<ArticleIcon />}
                    label={`${categoryData.count}개 포스트`}
                    size="small"
                    variant="filled"
                    sx={{
                      bgcolor: 'primary.light',
                      color: 'primary.contrastText',
                      fontWeight: 500,
                      transition: 'all 0.3s ease-in-out',
                    }}
                  />

                  {/* 순위 표시 (상위 3개) */}
                  {index < 3 && (
                    <Box
                      sx={{
                        position: 'absolute',
                        top: 8,
                        right: 8,
                        bgcolor: index === 0 ? 'gold' : index === 1 ? 'silver' : '#CD7F32',
                        color: 'white',
                        borderRadius: '50%',
                        width: 24,
                        height: 24,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '0.75rem',
                        fontWeight: 'bold',
                      }}
                    >
                      {index + 1}
                    </Box>
                  )}
                </Paper>
              </Grid>
            ))}
          </Grid>
        )}

        {/* 하단 안내 */}
        {!loading && categories.length > 0 && (
          <Box sx={{ textAlign: 'center', mt: 8, p: 4, bgcolor: 'grey.50', borderRadius: 2 }}>
            <Typography variant="h6" component="h3" sx={{ mb: 2, fontWeight: 600 }}>
              원하는 카테고리를 찾지 못하셨나요?
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
              검색 기능을 사용하여 더 정확한 결과를 찾아보세요.
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
              <MuiLink
                component={Link}
                href="/search"
                sx={{
                  textDecoration: 'none',
                  color: 'primary.main',
                  fontWeight: 600,
                  '&:hover': {
                    textDecoration: 'underline',
                  },
                }}
              >
                포스트 검색
              </MuiLink>
              <span style={{ color: '#666' }}>•</span>
              <MuiLink
                component={Link}
                href="/posts"
                sx={{
                  textDecoration: 'none',
                  color: 'primary.main',
                  fontWeight: 600,
                  '&:hover': {
                    textDecoration: 'underline',
                  },
                }}
              >
                모든 포스트
              </MuiLink>
            </Box>
          </Box>
        )}
      </Container>
    </Layout>
  );
}