// src/app/layout.tsx - Next.js 앱의 루트 레이아웃 컴포넌트

import { Metadata } from 'next';
import { Inter } from 'next/font/google';

// Google Fonts에서 Inter 폰트 로드
const inter = Inter({ 
  subsets: ['latin'],
  display: 'swap', // 폰트 로딩 최적화
});

// 메타데이터 설정 (SEO 최적화)
export const metadata: Metadata = {
  title: {
    template: '%s | Developer\'s Blog', // 페이지별 제목 템플릿
    default: 'Developer\'s Blog - 개발자를 위한 기술 블로그', // 기본 제목
  },
  description: 'React, Next.js, TypeScript 등 최신 웹 개발 기술과 실무 경험을 공유하는 개발자 블로그입니다.',
  keywords: [
    '개발 블로그',
    'React',
    'Next.js',
    'TypeScript',
    'JavaScript',
    '웹 개발',
    '프론트엔드',
    '프로그래밍',
    '기술 블로그',
    '개발자',
  ],
  authors: [{ name: 'Developer', url: 'https://your-blog-domain.com' }],
  creator: 'Developer',
  publisher: 'Developer\'s Blog',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  // Open Graph 메타태그 (소셜 미디어 공유용)
  openGraph: {
    type: 'website',
    locale: 'ko_KR',
    url: 'https://your-blog-domain.com',
    siteName: 'Developer\'s Blog',
    title: 'Developer\'s Blog - 개발자를 위한 기술 블로그',
    description: 'React, Next.js, TypeScript 등 최신 웹 개발 기술과 실무 경험을 공유하는 개발자 블로그입니다.',
    images: [
      {
        url: '/og-image.png', // 실제 사용 시 이미지 파일 추가 필요
        width: 1200,
        height: 630,
        alt: 'Developer\'s Blog',
      },
    ],
  },
  // Twitter 카드 메타태그
  twitter: {
    card: 'summary_large_image',
    title: 'Developer\'s Blog - 개발자를 위한 기술 블로그',
    description: 'React, Next.js, TypeScript 등 최신 웹 개발 기술과 실무 경험을 공유하는 개발자 블로그입니다.',
    images: ['/og-image.png'], // 실제 사용 시 이미지 파일 추가 필요
    creator: '@yourtwitterhandle', // 실제 트위터 핸들로 변경
  },
  // 모바일 웹앱 설정
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
  },
  // RSS 피드 링크
  alternates: {
    types: {
      'application/rss+xml': [
        {
          url: '/rss.xml',
          title: 'Developer\'s Blog RSS Feed',
        },
      ],
    },
  },
  // 로봇 크롤링 설정
  robots: {
    index: true,
    follow: true,
    nocache: false,
    googleBot: {
      index: true,
      follow: true,
      noimageindex: false,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  // 매니페스트 설정 (아이콘 파일이 준비된 후 활성화)
  // manifest: '/manifest.json',
  // 아이콘 설정 (아이콘 파일이 준비된 후 활성화)
  // icons: {
  //   icon: '/favicon.ico',
  //   apple: '/apple-touch-icon.png',
  // },
};

/**
 * 루트 레이아웃 컴포넌트
 * 모든 페이지에서 공통으로 적용되는 HTML 구조와 스타일을 정의
 */
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ko">
      <head>
        {/* Prism.js CSS (코드 하이라이팅) */}
        <link 
          href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css" 
          rel="stylesheet" 
        />
        {/* Material Icons */}
        <link 
          href="https://fonts.googleapis.com/icon?family=Material+Icons" 
          rel="stylesheet" 
        />
        {/* 파비콘 설정 (실제 사용 시 파비콘 파일들 추가 필요) */}
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/manifest.json" />
        {/* 테마 색상 */}
        <meta name="theme-color" content="#1976d2" />
        <meta name="msapplication-TileColor" content="#1976d2" />
      </head>
      <body className={inter.className}>
        {/* 메인 콘텐츠 */}
        {children}
        
        {/* Prism.js JavaScript (코드 하이라이팅) */}
        <script 
          src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-core.min.js"
          defer
        />
        <script 
          src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/autoloader/prism-autoloader.min.js"
          defer
        />
      </body>
    </html>
  );
}