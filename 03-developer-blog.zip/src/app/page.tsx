// src/app/page.tsx - 블로그 홈페이지 (SSG 방식)

import React from 'react';
import {
  Container,
  Typography,
  Box,
  Button,
  Grid,
  Paper,
} from '@mui/material';
import {
  TrendingUp as TrendingIcon,
  Star as StarIcon,
  Article as ArticleIcon,
  ArrowForward as ArrowForwardIcon,
} from '@mui/icons-material';
import Link from 'next/link';
import Layout from '@/components/Layout';
import PostCard from '@/components/PostCard';
import { getAllPosts, getFeaturedPosts, getCategoriesWithCount } from '@/lib/blog';

/**
 * 🎯 학습 목표: 정적 사이트 생성 (SSG)
 * 홈페이지 컴포넌트 - 빌드 시점에 정적으로 생성됨
 */
export default async function HomePage() {
  // 🎯 학습 목표: 파일 시스템 기반 데이터 처리
  // 서버에서 빌드 시점에 데이터 가져오기 (SSG)
  const [featuredPosts, recentPosts, categories] = await Promise.all([
    getFeaturedPosts(3),           // 추천 포스트 3개
    getAllPosts(6),                // 최신 포스트 6개
    getCategoriesWithCount(),      // 카테고리별 포스트 개수
  ]);

  return (
    <Layout>
      {/* 히어로 섹션 */}
      <Box
        sx={{
          bgcolor: 'primary.main',
          color: 'primary.contrastText',
          py: 8,
          textAlign: 'center',
        }}
      >
        <Container maxWidth="md">
          <Typography
            variant="h2"
            component="h1"
            gutterBottom
            sx={{
              fontWeight: 800,
              fontSize: { xs: '2rem', sm: '3rem', md: '3.5rem' },
              mb: 3,
            }}
          >
            개발자를 위한 기술 블로그
          </Typography>
          
          <Typography
            variant="h5"
            component="p"
            sx={{
              fontWeight: 300,
              opacity: 0.9,
              mb: 4,
              fontSize: { xs: '1.1rem', md: '1.3rem' },
              lineHeight: 1.6,
            }}
          >
            React, Next.js, TypeScript 등 최신 웹 개발 기술과 <br />
            실무 경험을 공유하는 개발자 블로그입니다.
          </Typography>
          
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link href="/posts" style={{ textDecoration: 'none' }}>
              <Button
                variant="contained"
                size="large"
                endIcon={<ArticleIcon />}
                sx={{
                  bgcolor: 'white',
                  color: 'primary.main',
                  fontWeight: 600,
                  px: 4,
                  py: 1.5,
                  '&:hover': {
                    bgcolor: 'grey.100',
                  },
                }}
              >
                모든 포스트 보기
              </Button>
            </Link>
            
            <Link href="/categories" style={{ textDecoration: 'none' }}>
              <Button
                variant="outlined"
                size="large"
                endIcon={<ArrowForwardIcon />}
                sx={{
                  borderColor: 'white',
                  color: 'white',
                  fontWeight: 600,
                  px: 4,
                  py: 1.5,
                  '&:hover': {
                    borderColor: 'white',
                    bgcolor: 'rgba(255, 255, 255, 0.1)',
                  },
                }}
              >
                카테고리 탐색
              </Button>
            </Link>
          </Box>
        </Container>
      </Box>

      {/* 🎯 추천 포스트 섹션 (정적 데이터) */}
      {featuredPosts.length > 0 && (
        <Box sx={{ py: 6, bgcolor: 'background.default' }}>
          <Container maxWidth="lg">
            <Box sx={{ textAlign: 'center', mb: 4 }}>
              <Typography
                variant="h4"
                component="h2"
                sx={{
                  fontWeight: 700,
                  mb: 2,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 2,
                }}
              >
                <StarIcon sx={{ fontSize: 40, color: 'warning.main' }} />
                추천 포스트
              </Typography>
              <Typography variant="body1" color="text.secondary">
                꼭 읽어보시길 추천하는 인기 포스트들입니다.
              </Typography>
            </Box>

            <Grid container spacing={3}>
              {featuredPosts.map((post) => (
                <Grid item xs={12} md={4} key={post.slug}>
                  <PostCard post={post} featured={true} />
                </Grid>
              ))}
            </Grid>
          </Container>
        </Box>
      )}

      {/* 🎯 최신 포스트 섹션 (정적 데이터) */}
      <Box sx={{ py: 6 }}>
        <Container maxWidth="lg">
          <Box sx={{ textAlign: 'center', mb: 4 }}>
            <Typography
              variant="h4"
              component="h2"
              sx={{
                fontWeight: 700,
                mb: 2,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 2,
              }}
            >
              <TrendingIcon sx={{ fontSize: 40, color: 'primary.main' }} />
              최신 포스트
            </Typography>
            <Typography variant="body1" color="text.secondary">
              최근에 작성된 따끈따끈한 새 글들을 만나보세요.
            </Typography>
          </Box>

          <Grid container spacing={3}>
            {recentPosts.map((post) => (
              <Grid item xs={12} sm={6} lg={4} key={post.slug}>
                <PostCard post={post} showFeatured={true} />
              </Grid>
            ))}
          </Grid>

          {/* 더 보기 버튼 */}
          <Box sx={{ textAlign: 'center', mt: 4 }}>
            <Link href="/posts" style={{ textDecoration: 'none' }}>
              <Button
                variant="outlined"
                size="large"
                endIcon={<ArrowForwardIcon />}
                sx={{
                  fontWeight: 600,
                  px: 4,
                  py: 1.5,
                }}
              >
                모든 포스트 보기
              </Button>
            </Link>
          </Box>
        </Container>
      </Box>

      {/* 🎯 인기 카테고리 섹션 (정적 데이터) */}
      {categories.length > 0 && (
        <Box sx={{ py: 6, bgcolor: 'background.default' }}>
          <Container maxWidth="lg">
            <Box sx={{ textAlign: 'center', mb: 4 }}>
              <Typography
                variant="h4"
                component="h2"
                sx={{ fontWeight: 700, mb: 2 }}
              >
                인기 카테고리
              </Typography>
              <Typography variant="body1" color="text.secondary">
                관심 있는 주제의 포스트들을 찾아보세요.
              </Typography>
            </Box>

            <Grid container spacing={3}>
              {categories.slice(0, 6).map((categoryData) => (
                <Grid item xs={12} sm={6} md={4} key={categoryData.category}>
                  <Link 
                    href={`/categories/${encodeURIComponent(categoryData.category)}`} 
                    style={{ textDecoration: 'none' }}
                  >
                    <Paper
                      elevation={2}
                      sx={{
                        p: 3,
                        textAlign: 'center',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease-in-out',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: 4,
                        },
                      }}
                    >
                      <Typography
                        variant="h6"
                        component="h3"
                        sx={{ fontWeight: 600, mb: 1 }}
                      >
                        {categoryData.category}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {categoryData.count}개의 포스트
                      </Typography>
                    </Paper>
                  </Link>
                </Grid>
              ))}
            </Grid>
          </Container>
        </Box>
      )}

      {/* CTA 섹션 */}
      <Box
        sx={{
          py: 8,
          textAlign: 'center',
          bgcolor: 'grey.50',
        }}
      >
        <Container maxWidth="md">
          <Typography variant="h4" component="h2" sx={{ fontWeight: 700, mb: 2 }}>
            새로운 포스트를 놓치지 마세요!
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
            RSS 피드를 구독하시면 새로운 글이 올라올 때마다 알림을 받을 수 있습니다.
          </Typography>
          <Button
            component="a"
            href="/rss.xml"
            target="_blank"
            variant="contained"
            size="large"
            sx={{ fontWeight: 600, px: 4, py: 1.5 }}
          >
            RSS 구독하기
          </Button>
        </Container>
      </Box>
    </Layout>
  );
}