// src/app/posts/[slug]/page.tsx - 개별 블로그 포스트 상세 페이지 (SSG 방식)

import React from 'react';
import { notFound } from 'next/navigation';
import {
  Container,
  Typography,
  Box,
  Chip,
  Paper,
  Divider,
  Button,
  Grid,
} from '@mui/material';
import {
  CalendarToday as CalendarIcon,
  Person as PersonIcon,
  Schedule as ScheduleIcon,
  ArrowBack as ArrowBackIcon,
  Share as ShareIcon,
} from '@mui/icons-material';
import Link from 'next/link';
import { format } from 'date-fns';
import { ko } from 'date-fns/locale';
import Layout from '@/components/Layout';
import PostCard from '@/components/PostCard';
import ShareButton from '@/components/ShareButton';
import { getPostBySlug, getAllPosts, getRelatedPosts } from '@/lib/blog';

// 🎯 학습 목표 1: generateStaticParams로 정적 경로 생성
export async function generateStaticParams() {
  const posts = await getAllPosts();
  
  // 모든 포스트의 slug를 기반으로 정적 경로 생성
  return posts.map((post) => ({
    slug: post.slug,
  }));
}

// 🎯 학습 목표 2: 메타데이터 생성 (SEO 최적화)
export async function generateMetadata({ params }: { params: { slug: string } }) {
  const post = await getPostBySlug(params.slug);

  if (!post) {
    return {
      title: '포스트를 찾을 수 없습니다 | Developer\'s Blog',
    };
  }

  return {
    title: `${post.title} | Developer's Blog`,
    description: post.excerpt,
    keywords: post.tags.join(', '),
    authors: [{ name: post.author }],
    openGraph: {
      title: post.title,
      description: post.excerpt,
      type: 'article',
      publishedTime: post.date,
      authors: [post.author],
      tags: post.tags,
    },
  };
}

/**
 * 🎯 학습 목표 3: 동적 라우팅과 파라미터 처리
 * 포스트 상세 페이지 컴포넌트 (서버 컴포넌트 + SSG)
 */
export default async function PostDetailPage({ 
  params 
}: { 
  params: { slug: string } 
}) {
  // 🎯 학습 목표 4: 파일 시스템 기반 데이터 처리
  const post = await getPostBySlug(params.slug);

  // 포스트가 없으면 404 페이지 표시
  if (!post) {
    notFound();
  }

  // 관련 포스트 가져오기 (같은 카테고리)
  const relatedPosts = await getRelatedPosts(post, 3);

  // 날짜 포맷팅
  const formattedDate = format(new Date(post.date), 'yyyy년 MM월 dd일', {
    locale: ko,
  });

  return (
    <Layout>
      <Container maxWidth="md" sx={{ py: 4 }}>
        {/* 상단 네비게이션 */}
        <Box sx={{ mb: 4 }}>
          <Link href="/posts" style={{ textDecoration: 'none' }}>
            <Button
              startIcon={<ArrowBackIcon />}
              variant="text"
              sx={{ mb: 2 }}
            >
              포스트 목록으로 돌아가기
            </Button>
          </Link>
        </Box>

        {/* 포스트 헤더 */}
        <Box sx={{ mb: 4 }}>
          {/* 카테고리 칩 */}
          <Box sx={{ mb: 2 }}>
            <Link href={`/categories/${encodeURIComponent(post.category)}`} style={{ textDecoration: 'none' }}>
              <Chip
                label={post.category}
                clickable
                color="primary"
                variant="outlined"
                sx={{ fontWeight: 500 }}
              />
            </Link>
          </Box>

          {/* 제목 */}
          <Typography
            variant="h3"
            component="h1"
            sx={{
              fontWeight: 700,
              lineHeight: 1.3,
              mb: 3,
              fontSize: { xs: '1.8rem', sm: '2.5rem', md: '3rem' },
            }}
          >
            {post.title}
          </Typography>

          {/* 메타 정보 */}
          <Box
            sx={{
              display: 'flex',
              flexDirection: { xs: 'column', sm: 'row' },
              alignItems: { xs: 'flex-start', sm: 'center' },
              gap: 2,
              mb: 3,
              color: 'text.secondary',
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <CalendarIcon sx={{ fontSize: 18 }} />
              <Typography variant="body2">{formattedDate}</Typography>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <PersonIcon sx={{ fontSize: 18 }} />
              <Typography variant="body2">{post.author}</Typography>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <ScheduleIcon sx={{ fontSize: 18 }} />
              <Typography variant="body2">{post.readingTime}</Typography>
            </Box>
          </Box>

          {/* 요약 */}
          <Typography
            variant="h6"
            component="p"
            sx={{
              color: 'text.secondary',
              fontWeight: 400,
              lineHeight: 1.6,
              mb: 3,
              fontStyle: 'italic',
              borderLeft: 4,
              borderColor: 'primary.main',
              pl: 2,
            }}
          >
            {post.excerpt}
          </Typography>

          {/* 태그들 */}
          {post.tags && post.tags.length > 0 && (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
              {post.tags.map((tag) => (
                <Link key={tag} href={`/search?tags=${encodeURIComponent(tag)}`} style={{ textDecoration: 'none' }}>
                  <Chip
                    label={`#${tag}`}
                    clickable
                    size="small"
                    variant="filled"
                    sx={{
                      bgcolor: 'grey.100',
                      color: 'text.primary',
                      '&:hover': {
                        bgcolor: 'grey.200',
                      },
                    }}
                  />
                </Link>
              ))}
            </Box>
          )}

          {/* 공유 버튼 */}
          <Box sx={{ display: 'flex', gap: 1 }}>
            <ShareButton
              title={post.title}
              text={post.excerpt}
            />
          </Box>
        </Box>

        <Divider sx={{ mb: 4 }} />

        {/* 🎯 학습 목표 5: 마크다운 파싱된 본문 */}
        <Paper
          elevation={0}
          sx={{
            p: 4,
            mb: 6,
            bgcolor: 'background.paper',
            // 🎯 학습 목표 6: 코드 하이라이팅 스타일
            '& h1': {
              fontSize: '2rem',
              fontWeight: 700,
              mb: 3,
              mt: 4,
              lineHeight: 1.3,
            },
            '& h2': {
              fontSize: '1.75rem',
              fontWeight: 600,
              mb: 2,
              mt: 3,
              lineHeight: 1.4,
            },
            '& h3': {
              fontSize: '1.5rem',
              fontWeight: 600,
              mb: 2,
              mt: 3,
              lineHeight: 1.4,
            },
            '& p': {
              fontSize: '1.1rem',
              lineHeight: 1.8,
              mb: 2,
              color: 'text.primary',
            },
            '& code': {
              bgcolor: 'grey.100',
              color: 'error.main',
              px: 1,
              py: 0.5,
              borderRadius: 1,
              fontSize: '0.9rem',
              fontFamily: 'monospace',
            },
            '& pre': {
              bgcolor: 'grey.900',
              color: 'white',
              p: 2,
              borderRadius: 2,
              overflow: 'auto',
              mb: 2,
              '& code': {
                bgcolor: 'transparent',
                color: 'inherit',
                p: 0,
              },
            },
          }}
        >
          {/* 🎯 마크다운에서 변환된 HTML 렌더링 */}
          <div dangerouslySetInnerHTML={{ __html: post.content }} />
        </Paper>

        {/* 관련 포스트 섹션 */}
        {relatedPosts.length > 0 && (
          <Box sx={{ mt: 6 }}>
            <Typography
              variant="h5"
              component="h2"
              sx={{ fontWeight: 600, mb: 3 }}
            >
              관련 포스트
            </Typography>
            <Grid container spacing={3}>
              {relatedPosts.map((relatedPost) => (
                <Grid item xs={12} md={4} key={relatedPost.slug}>
                  <PostCard post={relatedPost} />
                </Grid>
              ))}
            </Grid>
          </Box>
        )}

        {/* 하단 네비게이션 */}
        <Box sx={{ mt: 6, textAlign: 'center' }}>
          <Link href="/posts" style={{ textDecoration: 'none' }}>
            <Button
              variant="contained"
              startIcon={<ArrowBackIcon />}
              size="large"
            >
              다른 포스트 보기
            </Button>
          </Link>
        </Box>
      </Container>
    </Layout>
  );
}