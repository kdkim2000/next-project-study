// src/app/posts/page.tsx - 모든 블로그 포스트를 표시하는 목록 페이지

'use client';

import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Breadcrumbs,
  Link as MuiLink,
  CircularProgress,
} from '@mui/material';
import {
  Home as HomeIcon,
  Article as ArticleIcon,
} from '@mui/icons-material';
import Link from 'next/link';
import Layout from '@/components/Layout';
import PostList from '@/components/PostList';
import { BlogPost } from '@/types/blog';

/**
 * 포스트 목록 페이지 컴포넌트
 */
export default function PostsPage() {
  // 상태 관리
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  // 포스트 데이터 로딩
  useEffect(() => {
    const loadPosts = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/posts');
        const data = await response.json();
        
        if (data.success) {
          setPosts(data.data);
        } else {
          console.error('Failed to load posts:', data.error);
        }
      } catch (error) {
        console.error('Error loading posts:', error);
      } finally {
        setLoading(false);
      }
    };

    loadPosts();
  }, []);

  return (
    <Layout>
      <Container maxWidth="lg" sx={{ py: 4 }}>
        {/* 브레드크럼 네비게이션 */}
        <Box sx={{ mb: 4 }}>
          <Breadcrumbs aria-label="breadcrumb" separator="›">
            <MuiLink
              component={Link}
              href="/"
              color="inherit"
              sx={{
                display: 'flex',
                alignItems: 'center',
                textDecoration: 'none',
                '&:hover': {
                  textDecoration: 'underline',
                },
              }}
            >
              <HomeIcon sx={{ mr: 0.5, fontSize: 20 }} />
              홈
            </MuiLink>
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                color: 'text.primary',
              }}
            >
              <ArticleIcon sx={{ mr: 0.5, fontSize: 20 }} />
              포스트
            </Box>
          </Breadcrumbs>
        </Box>

        {/* 페이지 헤더 */}
        <Box sx={{ textAlign: 'center', mb: 6 }}>
          <Typography
            variant="h3"
            component="h1"
            sx={{
              fontWeight: 700,
              mb: 2,
              fontSize: { xs: '2rem', sm: '2.5rem', md: '3rem' },
            }}
          >
            모든 포스트
          </Typography>
          
          <Typography
            variant="h6"
            component="p"
            color="text.secondary"
            sx={{
              fontWeight: 400,
              maxWidth: 600,
              margin: '0 auto',
              lineHeight: 1.6,
            }}
          >
            개발과 관련된 다양한 주제의 포스트들을 만나보세요. <br />
            {!loading && posts.length > 0 && (
              <>현재 총 <strong>{posts.length}개</strong>의 포스트가 있습니다.</>
            )}
          </Typography>
        </Box>

        {/* 로딩 상태 */}
        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
            <CircularProgress size={60} />
          </Box>
        )}

        {/* 포스트 통계 정보 */}
        {!loading && posts.length > 0 && (
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              gap: 4,
              mb: 4,
              flexWrap: 'wrap',
            }}
          >
            <Box sx={{ textAlign: 'center' }}>
              <Typography variant="h4" component="div" sx={{ fontWeight: 700, color: 'primary.main' }}>
                {posts.length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                전체 포스트
              </Typography>
            </Box>
            
            <Box sx={{ textAlign: 'center' }}>
              <Typography variant="h4" component="div" sx={{ fontWeight: 700, color: 'secondary.main' }}>
                {posts.filter(post => post.featured).length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                추천 포스트
              </Typography>
            </Box>

            <Box sx={{ textAlign: 'center' }}>
              <Typography variant="h4" component="div" sx={{ fontWeight: 700, color: 'success.main' }}>
                {new Set(posts.map(post => post.category)).size}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                카테고리 수
              </Typography>
            </Box>
          </Box>
        )}

        {/* 포스트 리스트 */}
        <PostList 
          posts={posts} 
          loading={loading}
          emptyMessage="아직 작성된 포스트가 없습니다. 첫 번째 포스트를 작성해보세요!"
          showFeatured={true}
        />

        {/* 하단 안내 메시지 */}
        {!loading && posts.length > 0 && (
          <Box sx={{ textAlign: 'center', mt: 6, p: 4, bgcolor: 'grey.50', borderRadius: 2 }}>
            <Typography variant="h6" component="h3" sx={{ mb: 2, fontWeight: 600 }}>
              더 많은 콘텐츠를 원하시나요?
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
              관심 있는 특정 주제나 카테고리의 포스트를 찾아보세요.
            </Typography>
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
              <MuiLink
                component={Link}
                href="/categories"
                sx={{
                  textDecoration: 'none',
                  color: 'primary.main',
                  fontWeight: 600,
                  '&:hover': {
                    textDecoration: 'underline',
                  },
                }}
              >
                카테고리별 탐색
              </MuiLink>
              <span style={{ color: '#666' }}>•</span>
              <MuiLink
                component={Link}
                href="/search"
                sx={{
                  textDecoration: 'none',
                  color: 'primary.main',
                  fontWeight: 600,
                  '&:hover': {
                    textDecoration: 'underline',
                  },
                }}
              >
                포스트 검색
              </MuiLink>
              <span style={{ color: '#666' }}>•</span>
              <MuiLink
                component="a"
                href="/rss.xml"
                target="_blank"
                sx={{
                  textDecoration: 'none',
                  color: 'primary.main',
                  fontWeight: 600,
                  '&:hover': {
                    textDecoration: 'underline',
                  },
                }}
              >
                RSS 구독
              </MuiLink>
            </Box>
          </Box>
        )}
      </Container>
    </Layout>
  );
}