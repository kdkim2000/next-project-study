// src/app/rss.xml/route.ts - RSS 피드를 생성하는 API 라우트

import { NextResponse } from 'next/server';
import { generateRSSFeed } from '@/lib/rss';

/**
 * RSS 피드 GET 요청 핸들러
 * /rss.xml 경로로 접근했을 때 RSS XML을 생성하여 반환
 */
export async function GET() {
  try {
    // RSS XML 생성
    const rssXml = await generateRSSFeed();
    
    // RSS XML을 응답으로 반환
    return new NextResponse(rssXml, {
      status: 200,
      headers: {
        'Content-Type': 'application/rss+xml; charset=utf-8', // RSS XML 콘텐츠 타입
        'Cache-Control': 'public, max-age=3600, s-maxage=3600', // 1시간 캐싱
      },
    });
  } catch (error) {
    console.error('RSS 피드 생성 중 오류:', error);
    
    // 오류 발생 시 500 에러 반환
    return new NextResponse('RSS 피드를 생성할 수 없습니다.', {
      status: 500,
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
      },
    });
  }
}