// src/components/PostCard.tsx - 블로그 포스트를 카드 형태로 표시하는 컴포넌트

'use client';

import React from 'react';
import {
  Card,
  CardContent,
  CardActions,
  Typography,
  Chip,
  Box,
  Button,
  useTheme,
  alpha,
} from '@mui/material';
import {
  CalendarToday as CalendarIcon,
  Person as PersonIcon,
  Schedule as ScheduleIcon,
  Star as StarIcon,
} from '@mui/icons-material';
import Link from 'next/link';
import { format } from 'date-fns';
import { ko } from 'date-fns/locale';
import { BlogPost } from '@/types/blog';

/**
 * PostCard 컴포넌트의 Props 타입
 */
interface PostCardProps {
  post: BlogPost;        // 표시할 블로그 포스트 데이터
  featured?: boolean;    // 추천 포스트 여부 (선택적)
}

/**
 * 블로그 포스트 카드 컴포넌트
 */
const PostCard: React.FC<PostCardProps> = ({ post, featured = false }) => {
  const theme = useTheme();

  // 날짜 포맷팅 (한국어)
  const formattedDate = format(new Date(post.date), 'yyyy년 MM월 dd일', {
    locale: ko,
  });

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        transition: 'all 0.3s ease-in-out',
        position: 'relative',
        overflow: 'visible',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: theme.shadows[8],
          '& .post-title': {
            color: theme.palette.primary.main,
          },
        },
      }}
    >
      {/* 추천 포스트 배지 */}
      {(featured || (showFeatured && post.featured)) && (
        <Box
          sx={{
            position: 'absolute',
            top: -8,
            right: 16,
            zIndex: 1,
            bgcolor: theme.palette.warning.main,
            color: theme.palette.warning.contrastText,
            borderRadius: '50%',
            p: 1,
            boxShadow: theme.shadows[4],
          }}
        >
          <StarIcon sx={{ fontSize: 20 }} />
        </Box>
      )}

      <CardContent sx={{ flexGrow: 1, p: 3 }}>
        {/* 카테고리 칩 */}
        <Box sx={{ mb: 2 }}>
          <Chip
            label={post.category}
            size="small"
            variant="outlined"
            sx={{
              bgcolor: alpha(theme.palette.primary.main, 0.1),
              color: theme.palette.primary.main,
              borderColor: theme.palette.primary.main,
              fontWeight: 500,
            }}
          />
        </Box>

        {/* 포스트 제목 */}
        <Typography
          variant="h6"
          component="h3"
          className="post-title"
          sx={{
            fontWeight: 600,
            lineHeight: 1.4,
            mb: 2,
            transition: 'color 0.2s ease-in-out',
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
        >
          {post.title}
        </Typography>

        {/* 포스트 요약 */}
        <Typography
          variant="body2"
          color="text.secondary"
          sx={{
            lineHeight: 1.6,
            mb: 3,
            display: '-webkit-box',
            WebkitLineClamp: 3,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
        >
          {post.excerpt}
        </Typography>

        {/* 메타 정보 (작성일, 작성자, 읽기 시간) */}
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            gap: 1,
            mb: 2,
          }}
        >
          {/* 작성일 */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <CalendarIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
            <Typography variant="caption" color="text.secondary">
              {formattedDate}
            </Typography>
          </Box>

          {/* 작성자 */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <PersonIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
            <Typography variant="caption" color="text.secondary">
              {post.author}
            </Typography>
          </Box>

          {/* 읽기 시간 */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <ScheduleIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
            <Typography variant="caption" color="text.secondary">
              {post.readingTime}
            </Typography>
          </Box>
        </Box>

        {/* 태그들 */}
        {post.tags && post.tags.length > 0 && (
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {post.tags.slice(0, 3).map((tag) => (
              <Chip
                key={tag}
                label={`#${tag}`}
                size="small"
                variant="filled"
                sx={{
                  bgcolor: alpha(theme.palette.secondary.main, 0.1),
                  color: theme.palette.secondary.main,
                  fontSize: '0.75rem',
                  height: 24,
                  '&:hover': {
                    bgcolor: alpha(theme.palette.secondary.main, 0.2),
                  },
                }}
              />
            ))}
            {post.tags.length > 3 && (
              <Chip
                label={`+${post.tags.length - 3}`}
                size="small"
                variant="outlined"
                sx={{
                  fontSize: '0.75rem',
                  height: 24,
                  color: 'text.secondary',
                  borderColor: 'text.secondary',
                }}
              />
            )}
          </Box>
        )}
      </CardContent>

      {/* 카드 액션 (더 읽기 버튼) */}
      <CardActions sx={{ px: 3, pb: 3, pt: 0 }}>
        <Link href={`/posts/${post.slug}`} style={{ width: '100%', textDecoration: 'none' }}>
          <Button
            variant="outlined"
            size="small"
            fullWidth
            sx={{
              fontWeight: 500,
              textTransform: 'none',
              py: 1,
              '&:hover': {
                bgcolor: theme.palette.primary.main,
                color: theme.palette.primary.contrastText,
                borderColor: theme.palette.primary.main,
              },
              transition: 'all 0.2s ease-in-out',
            }}
          >
            더 읽기
          </Button>
        </Link>
      </CardActions>
    </Card>
  );
};

export default PostCard;