// src/lib/blog.ts - 블로그 관련 유틸리티 함수들 (서버 전용)

import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { remark } from 'remark';
import html from 'remark-html';
import readingTime from 'reading-time';
import { BlogPost, PostMetadata, CategoryCount, SearchFilters } from '@/types/blog';

// 블로그 포스트가 저장된 디렉토리 경로
const postsDirectory = path.join(process.cwd(), 'content/posts');

/**
 * 모든 블로그 포스트를 가져오는 함수
 * @param limit - 가져올 포스트 개수 제한 (선택적)
 * @returns 블로그 포스트 배열 (최신순으로 정렬)
 */
export async function getAllPosts(limit?: number): Promise<BlogPost[]> {
  try {
    // content/posts 디렉토리가 없으면 빈 배열 반환
    if (!fs.existsSync(postsDirectory)) {
      return [];
    }

    // 모든 마크다운 파일명 가져오기
    const fileNames = fs.readdirSync(postsDirectory)
      .filter(name => name.endsWith('.md')); // .md 파일만 필터링

    // 각 파일을 BlogPost 객체로 변환
    const allPosts: BlogPost[] = [];
    
    for (const fileName of fileNames) {
      const post = await getPostBySlug(fileName.replace(/\.md$/, ''));
      if (post) {
        allPosts.push(post);
      }
    }

    // 날짜순으로 정렬 (최신 포스트가 먼저 오도록)
    const sortedPosts = allPosts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    // limit가 지정된 경우 해당 개수만 반환
    return limit ? sortedPosts.slice(0, limit) : sortedPosts;
  } catch (error) {
    console.error('Error fetching posts:', error);
    return [];
  }
}

/**
 * 특정 slug로 블로그 포스트를 가져오는 함수
 * @param slug - 포스트의 고유 식별자
 * @returns 블로그 포스트 객체 또는 null
 */
export async function getPostBySlug(slug: string): Promise<BlogPost | null> {
  try {
    const fullPath = path.join(postsDirectory, `${slug}.md`);
    
    // 파일이 존재하지 않으면 null 반환
    if (!fs.existsSync(fullPath)) {
      return null;
    }

    // 마크다운 파일 읽기
    const fileContents = fs.readFileSync(fullPath, 'utf8');
    
    // gray-matter로 메타데이터와 본문 분리
    const { data, content } = matter(fileContents);
    const metadata = data as PostMetadata;

    // 마크다운을 HTML로 변환
    const processedContent = await remark()
      .use(html)
      .process(content);
    const htmlContent = processedContent.toString();

    // 읽기 시간 계산
    const readingTimeResult = readingTime(content);

    // BlogPost 객체 생성
    const post: BlogPost = {
      slug,
      title: metadata.title,
      excerpt: metadata.excerpt,
      content: htmlContent,
      date: metadata.date,
      author: metadata.author,
      category: metadata.category,
      tags: metadata.tags || [],
      readingTime: readingTimeResult.text,
      featured: metadata.featured || false,
    };

    return post;
  } catch (error) {
    console.error(`Error fetching post ${slug}:`, error);
    return null;
  }
}

/**
 * 모든 카테고리와 각 카테고리별 포스트 개수를 가져오는 함수
 * @returns 카테고리별 포스트 개수 배열
 */
export async function getCategoriesWithCount(): Promise<CategoryCount[]> {
  const posts = await getAllPosts();
  
  // 카테고리별로 포스트 개수 집계
  const categoryMap = new Map<string, number>();
  
  posts.forEach(post => {
    const current = categoryMap.get(post.category) || 0;
    categoryMap.set(post.category, current + 1);
  });

  // Map을 배열로 변환하고 포스트 개수 내림차순으로 정렬
  return Array.from(categoryMap.entries())
    .map(([category, count]) => ({ category, count }))
    .sort((a, b) => b.count - a.count);
}

/**
 * 모든 태그를 중복 없이 가져오는 함수
 * @returns 태그 배열 (알파벳 순으로 정렬)
 */
export async function getAllTags(): Promise<string[]> {
  const posts = await getAllPosts();
  
  // 모든 포스트의 태그를 하나의 배열로 합치기
  const allTags = posts.flatMap(post => post.tags);
  
  // 중복 제거 후 알파벳 순으로 정렬
  return Array.from(new Set(allTags)).sort();
}

/**
 * 검색 필터에 따라 포스트를 필터링하는 함수
 * @param filters - 검색 필터 객체
 * @returns 필터링된 블로그 포스트 배열
 */
export async function searchPosts(filters: SearchFilters): Promise<BlogPost[]> {
  const allPosts = await getAllPosts();

  return allPosts.filter(post => {
    // 검색 키워드 필터링 (제목, 요약, 내용에서 검색)
    if (filters.query) {
      const query = filters.query.toLowerCase();
      const searchableText = `${post.title} ${post.excerpt}`.toLowerCase();
      if (!searchableText.includes(query)) {
        return false;
      }
    }

    // 카테고리 필터링
    if (filters.category && post.category !== filters.category) {
      return false;
    }

    // 태그 필터링 (선택된 태그 중 하나 이상이 포스트에 있어야 함)
    if (filters.tags && filters.tags.length > 0) {
      const hasMatchingTag = filters.tags.some(tag => post.tags.includes(tag));
      if (!hasMatchingTag) {
        return false;
      }
    }

    return true;
  });
}

/**
 * 추천 포스트들을 가져오는 함수
 * @param limit - 가져올 추천 포스트 개수 (기본값: 3)
 * @returns 추천 블로그 포스트 배열
 */
export async function getFeaturedPosts(limit: number = 3): Promise<BlogPost[]> {
  const allPosts = await getAllPosts();
  
  return allPosts
    .filter(post => post.featured) // featured가 true인 포스트만 필터링
    .slice(0, limit); // 지정된 개수만큼 자르기
}

/**
 * 관련 포스트를 가져오는 함수 (같은 카테고리의 다른 포스트)
 * @param currentPost - 현재 포스트
 * @param limit - 가져올 관련 포스트 개수 (기본값: 3)
 * @returns 관련 블로그 포스트 배열
 */
export async function getRelatedPosts(currentPost: BlogPost, limit: number = 3): Promise<BlogPost[]> {
  const allPosts = await getAllPosts();
  
  // 현재 포스트 제외하고 같은 카테고리의 포스트들 가져오기
  const relatedPosts = allPosts
    .filter(post => post.slug !== currentPost.slug && post.category === currentPost.category)
    .slice(0, limit);
  
  return relatedPosts;
}