// src/types/blog.ts - 블로그 관련 타입 정의 파일

/**
 * 블로그 포스트의 메타데이터를 정의하는 인터페이스
 */
export interface BlogPost {
  slug: string;           // URL에 사용될 고유 식별자 (예: "my-first-post")
  title: string;          // 포스트 제목
  excerpt: string;        // 포스트 요약
  content: string;        // 마크다운으로 작성된 본문 내용
  date: string;          // 작성일 (YYYY-MM-DD 형식)
  author: string;        // 작성자 이름
  category: string;      // 카테고리 (예: "React", "JavaScript")
  tags: string[];        // 태그 배열 (예: ["tutorial", "beginner"])
  readingTime: string;   // 예상 읽기 시간 (예: "5 min read")
  featured?: boolean;    // 추천 포스트 여부 (선택적)
}

/**
 * 마크다운 파일에서 파싱된 메타데이터
 */
export interface PostMetadata {
  title: string;
  excerpt: string;
  date: string;
  author: string;
  category: string;
  tags: string[];
  featured?: boolean;
}

/**
 * 카테고리별 포스트 개수 정보
 */
export interface CategoryCount {
  category: string;
  count: number;
}

/**
 * 검색 필터 옵션
 */
export interface SearchFilters {
  query?: string;        // 검색 키워드
  category?: string;     // 선택된 카테고리
  tags?: string[];       // 선택된 태그들
}

/**
 * RSS 피드 아이템
 */
export interface RSSItem {
  title: string;
  description: string;
  link: string;
  pubDate: string;
  category: string;
}