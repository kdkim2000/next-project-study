# Task Master Pro 완전한 설치 가이드

## 1단계: 프로젝트 생성
```bash
# Next.js 프로젝트 생성
npx create-next-app@latest task-master-pro

# 옵션 선택:
# TypeScript: Yes
# ESLint: Yes  
# Tailwind CSS: No
# src/ directory: Yes
# App Router: Yes
# import alias: Yes

cd task-master-pro
```

## 2단계: 패키지 설치
```bash
# 기본 의존성
npm install @mui/material @emotion/react @emotion/styled @mui/icons-material @mui/material-nextjs

# 추가 라이브러리
npm install zod @dnd-kit/core @dnd-kit/sortable @dnd-kit/utilities

# 데이터베이스
npm install prisma @prisma/client

# 개발 도구
npm install -D sqlite3 tsx @types/node
```

## 3단계: 환경 변수 설정
`.env` 파일 생성:
```bash
DATABASE_URL="file:./dev.db"
NODE_ENV="development"
```

## 4단계: Prisma 설정
```bash
# Prisma 초기화
npx prisma init --datasource-provider sqlite

# 스키마 파일 생성 후 (prisma/schema.prisma)
npx prisma db push

# 클라이언트 생성
npx prisma generate

# 샘플 데이터 입력 (선택사항)
npx tsx prisma/seed.ts
```

## 5단계: 파일 생성
위에서 제공한 모든 파일들을 해당 경로에 복사

## 6단계: 개발 서버 실행
```bash
npm run dev
```

## 문제 해결
1. **500 에러**: API 라우트 파일들이 없으면 임시로 샘플 데이터 사용
2. **Prisma 에러**: `npx prisma generate` 재실행
3. **타입 에러**: 개발 서버 재시작

## API 라우트 활성화
나중에 API 라우트 파일들을 생성한 후, page.tsx에서 주석 처리된 API 호출 코드를 활성화하세요.