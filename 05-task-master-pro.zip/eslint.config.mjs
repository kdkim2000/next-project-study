// eslint.config.mjs
// 초보자를 위한 느슨한 ESLint 설정

import { dirname } from "path";
import { fileURLToPath } from "url";
import { FlatCompat } from "@eslint/eslintrc";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const compat = new FlatCompat({
  baseDirectory: __dirname,
});

const eslintConfig = [
  ...compat.extends("next/core-web-vitals", "next/typescript"),
  {
    rules: {
      // 초보자를 위해 엄격한 규칙들을 완화
      "@typescript-eslint/no-unused-vars": "warn", // 미사용 변수는 경고만
      "@typescript-eslint/no-explicit-any": "off", // any 타입 허용
      "react-hooks/exhaustive-deps": "warn", // 의존성 배열 경고만
      "@next/next/no-img-element": "off", // img 태그 사용 허용
      "prefer-const": "warn", // const 권장사항을 경고로
      "no-console": "off", // console.log 허용
    },
  },
];

export default eslintConfig;