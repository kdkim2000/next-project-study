// prisma/seed.ts
// 데이터베이스 초기 데이터 입력 스크립트

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('데이터베이스 초기화 시작...')

  // 기존 데이터 삭제 (개발 환경에서만)
  if (process.env.NODE_ENV === 'development') {
    await prisma.task.deleteMany()
    await prisma.category.deleteMany()
    console.log('기존 데이터 삭제 완료')
  }

  // 기본 카테고리 생성
  const categories = await prisma.category.createMany({
    data: [
      { name: '업무', color: '#1976d2' },
      { name: '개인', color: '#388e3c' },
      { name: '쇼핑', color: '#f57c00' },
      { name: '건강', color: '#7b1fa2' },
      { name: '학습', color: '#d32f2f' },
    ],
    skipDuplicates: true
  })

  console.log(`${categories.count}개 카테고리 생성 완료`)

  // 샘플 할 일 데이터 생성
  const sampleTasks = [
    {
      title: '프로젝트 기획서 작성',
      description: '새로운 웹 애플리케이션 프로젝트의 기획서를 작성합니다.',
      priority: 'high' as const,
      category: '업무',
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3일 후
      order: 1,
      completed: false
    },
    {
      title: '장보기 목록 작성',
      description: '이번 주말에 필요한 식료품과 생활용품 목록을 정리합니다.',
      priority: 'medium' as const,
      category: '쇼핑',
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2일 후
      order: 2,
      completed: false
    },
    {
      title: 'React 공식 문서 읽기',
      description: 'React 18 버전의 새로운 기능들에 대해 공부합니다.',
      priority: 'medium' as const,
      category: '학습',
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 1주일 후
      order: 3,
      completed: false
    },
    {
      title: '운동하기',
      description: '헬스장에서 30분간 유산소 운동을 합니다.',
      priority: 'low' as const,
      category: '건강',
      dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1일 후
      order: 4,
      completed: true
    },
    {
      title: '친구와 점심 약속',
      description: '오랜만에 만나는 친구와 맛있는 점심을 먹습니다.',
      priority: 'high' as const,
      category: '개인',
      dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1일 후
      order: 5,
      completed: false
    },
    {
      title: '책 읽기 - Clean Code',
      description: '클린 코드 책의 5장까지 읽고 정리합니다.',
      priority: 'medium' as const,
      category: '학습',
      dueDate: null, // 마감일 없음
      order: 6,
      completed: false
    }
  ]

  for (const taskData of sampleTasks) {
    await prisma.task.create({
      data: taskData
    })
  }

  console.log(`${sampleTasks.length}개 샘플 할 일 생성 완료`)
  console.log('데이터베이스 초기화 완료!')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error('데이터베이스 초기화 오류:', e)
    await prisma.$disconnect()
    process.exit(1)
  })