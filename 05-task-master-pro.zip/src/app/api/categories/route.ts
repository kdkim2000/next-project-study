// src/app/api/categories/route.ts
// 카테고리 관리를 위한 API 라우트

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET: 모든 카테고리 조회
export async function GET() {
  try {
    const categories = await prisma.category.findMany({
      orderBy: {
        name: 'asc' // 이름순 정렬
      }
    })

    return NextResponse.json(categories)
  } catch (error) {
    console.error('카테고리 목록 조회 오류:', error)
    return NextResponse.json(
      { error: '카테고리 목록을 불러오는 중 오류가 발생했습니다' },
      { status: 500 }
    )
  }
}

// POST: 새 카테고리 생성
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // 중복 카테고리 체크
    const existingCategory = await prisma.category.findUnique({
      where: { name: body.name }
    })

    if (existingCategory) {
      return NextResponse.json(
        { error: '이미 존재하는 카테고리입니다' },
        { status: 400 }
      )
    }

    const category = await prisma.category.create({
      data: {
        name: body.name,
        color: body.color || '#1976d2'
      }
    })

    return NextResponse.json(category, { status: 201 })
  } catch (error) {
    console.error('카테고리 생성 오류:', error)
    return NextResponse.json(
      { error: '카테고리 생성 중 오류가 발생했습니다' },
      { status: 500 }
    )
  }
}

// DELETE: 카테고리 삭제
export async function DELETE(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const id = url.searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: '카테고리 ID가 필요합니다' },
        { status: 400 }
      )
    }

    // 해당 카테고리를 사용하는 할 일이 있는지 체크
    const tasksWithCategory = await prisma.task.findMany({
      where: {
        category: {
          equals: (await prisma.category.findUnique({
            where: { id }
          }))?.name
        }
      }
    })

    if (tasksWithCategory.length > 0) {
      return NextResponse.json(
        { error: '사용 중인 카테고리는 삭제할 수 없습니다' },
        { status: 400 }
      )
    }

    await prisma.category.delete({
      where: { id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('카테고리 삭제 오류:', error)
    return NextResponse.json(
      { error: '카테고리 삭제 중 오류가 발생했습니다' },
      { status: 500 }
    )
  }
}