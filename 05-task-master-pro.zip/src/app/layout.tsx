// src/app/layout.tsx
// 애플리케이션의 루트 레이아웃 컴포넌트

import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { ThemeProvider } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline'
import { AppRouterCacheProvider } from '@mui/material-nextjs/v14-appRouter'
import { theme } from '@/lib/theme'

// Google Fonts - Inter 폰트 로드
const inter = Inter({ subsets: ['latin'] })

// 메타데이터 설정
export const metadata: Metadata = {
  title: 'Task Master Pro - 할 일 관리 애플리케이션',
  description: 'React와 Next.js로 만든 현대적인 할 일 관리 도구',
  keywords: ['할일관리', 'todo', 'task', 'nextjs', 'react'],
}

// 루트 레이아웃 컴포넌트
export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ko">
      <body className={inter.className}>
        {/* Material-UI와 Next.js App Router 호환성을 위한 캐시 프로바이더 */}
        <AppRouterCacheProvider>
          {/* Material-UI 테마 프로바이더 */}
          <ThemeProvider theme={theme}>
            {/* CSS 베이스라인 - 브라우저 기본 스타일 초기화 */}
            <CssBaseline />
            {children}
          </ThemeProvider>
        </AppRouterCacheProvider>
      </body>
    </html>
  )
}