// src/app/page.tsx
// 메인 페이지 - 할 일 관리 애플리케이션의 메인 화면

'use client'

import { useState, useEffect, useMemo } from 'react'
import {
  Container,
  Typography,
  Box,
  AppBar,
  Toolbar,
  IconButton,
  Fab,
  useTheme,
  useMediaQuery,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
} from '@mui/material'
import {
  Assignment,
  Menu as MenuIcon,
  Add,
  Dashboard,
  Category as CategoryIcon,
  Analytics,
} from '@mui/icons-material'

import { TaskList } from '@/components/TaskList'
import { AddTaskForm } from '@/components/AddTaskForm'
import { FilterSortBar } from '@/components/FilterSortBar'
import { Task, Category as CategoryType, FilterOption, SortOption, Priority } from '@/lib/types'

// 임시 샘플 데이터 (API 준비 전까지)
const getSampleTasks = (): Task[] => [
  {
    id: '1',
    title: '프로젝트 기획서 작성',
    description: '새로운 웹 애플리케이션 프로젝트의 기획서를 작성합니다.',
    priority: 'high' as Priority,
    category: '업무',
    dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
    completed: false,
    createdAt: new Date(),
    updatedAt: new Date(),
    order: 1
  },
  {
    id: '2',
    title: '장보기',
    description: '주말에 필요한 식료품 구매',
    priority: 'medium' as Priority,
    category: '개인',
    dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    completed: false,
    createdAt: new Date(),
    updatedAt: new Date(),
    order: 2
  },
  {
    id: '3',
    title: 'React 공부하기',
    description: 'React 18 새로운 기능 학습',
    priority: 'medium' as Priority,
    category: '학습',
    dueDate: null,
    completed: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    order: 3
  }
]

const getSampleCategories = (): CategoryType[] => [
  { id: '1', name: '업무', color: '#1976d2' },
  { id: '2', name: '개인', color: '#388e3c' },
  { id: '3', name: '학습', color: '#f57c00' },
]

// 클라이언트에서 사용할 데이터 페칭 함수들
async function fetchTasks(): Promise<Task[]> {
  try {
    // API가 준비되면 주석 해제
    // const response = await fetch('/api/tasks')
    // if (!response.ok) throw new Error('Failed to fetch tasks')
    // return response.json()
    
    // 임시로 샘플 데이터 사용
    return getSampleTasks()
  } catch (error) {
    console.error('할 일 목록 로딩 오류:', error)
    return getSampleTasks() // 오류 시에도 샘플 데이터 반환
  }
}

async function fetchCategories(): Promise<CategoryType[]> {
  try {
    // API가 준비되면 주석 해제
    // const response = await fetch('/api/categories')
    // if (!response.ok) throw new Error('Failed to fetch categories')
    // return response.json()
    
    // 임시로 샘플 데이터 사용
    return getSampleCategories()
  } catch (error) {
    console.error('카테고리 목록 로딩 오류:', error)
    return getSampleCategories() // 오류 시에도 샘플 데이터 반환
  }
}

export default function HomePage() {
  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down('md'))

  // 상태 관리
  const [tasks, setTasks] = useState<Task[]>([])
  const [categories, setCategories] = useState<CategoryType[]>([])
  const [loading, setLoading] = useState(true)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [showAddForm, setShowAddForm] = useState(false)

  // 필터 및 정렬 상태
  const [searchTerm, setSearchTerm] = useState('')
  const [filterOption, setFilterOption] = useState<FilterOption>('all')
  const [selectedPriority, setSelectedPriority] = useState<Priority | 'all'>('all')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [sortOption, setSortOption] = useState<SortOption>('createdAt')

  // 데이터 로딩
  const loadData = async () => {
    setLoading(true)
    try {
      const [tasksData, categoriesData] = await Promise.all([
        fetchTasks(),
        fetchCategories()
      ])
      setTasks(tasksData)
      setCategories(categoriesData)
    } catch (error) {
      console.error('데이터 로딩 오류:', error)
    } finally {
      setLoading(false)
    }
  }

  // 초기 데이터 로딩
  useEffect(() => {
    loadData()
  }, [])

  // 필터링 및 정렬된 할 일 목록 계산
  const filteredAndSortedTasks = useMemo(() => {
    let filtered = [...tasks]

    // 검색 필터
    if (searchTerm) {
      filtered = filtered.filter(task =>
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    // 상태 필터
    if (filterOption === 'active') {
      filtered = filtered.filter(task => !task.completed)
    } else if (filterOption === 'completed') {
      filtered = filtered.filter(task => task.completed)
    }

    // 우선순위 필터
    if (selectedPriority !== 'all') {
      filtered = filtered.filter(task => task.priority === selectedPriority)
    }

    // 카테고리 필터
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(task => task.category === selectedCategory)
    }

    // 정렬
    filtered.sort((a, b) => {
      switch (sortOption) {
        case 'dueDate':
          if (!a.dueDate) return 1
          if (!b.dueDate) return -1
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
        
        case 'priority':
          const priorityOrder = { high: 3, medium: 2, low: 1 }
          return priorityOrder[b.priority] - priorityOrder[a.priority]
        
        case 'alphabetical':
          return a.title.localeCompare(b.title, 'ko')
        
        case 'createdAt':
        default:
          return a.order - b.order // 사용자 지정 순서 우선
      }
    })

    return filtered
  }, [tasks, searchTerm, filterOption, selectedPriority, selectedCategory, sortOption])

  // 할 일 통계 계산
  const taskCounts = useMemo(() => ({
    total: tasks.length,
    active: tasks.filter(task => !task.completed).length,
    completed: tasks.filter(task => task.completed).length,
  }), [tasks])

  // 사용 가능한 카테고리 목록
  const availableCategories = useMemo(() => {
    const taskCategories = [...new Set(tasks.map(task => task.category))]
    const categoryNames = categories.map(cat => cat.name)
    return [...new Set([...taskCategories, ...categoryNames, 'general'])]
  }, [tasks, categories])

  // 사이드바 메뉴 항목들
  const menuItems = [
    { text: '대시보드', icon: <Dashboard />, action: () => {} },
    { text: '카테고리 관리', icon: <CategoryIcon />, action: () => {} },
    { text: '통계', icon: <Analytics />, action: () => {} },
  ]

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/* 앱바 */}
      <AppBar position="static" elevation={1}>
        <Toolbar>
          {isMobile && (
            <IconButton
              edge="start"
              color="inherit"
              onClick={() => setDrawerOpen(true)}
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>
          )}
          
          <Assignment sx={{ mr: 2 }} />
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Task Master Pro
          </Typography>
          
          {!isMobile && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Typography variant="body2" color="inherit">
                총 {taskCounts.total}개 • 완료 {taskCounts.completed}개
              </Typography>
            </Box>
          )}
        </Toolbar>
      </AppBar>

      {/* 모바일 드로어 */}
      <Drawer
        anchor="left"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        sx={{ display: { xs: 'block', md: 'none' } }}
      >
        <Box sx={{ width: 250, p: 2 }}>
          <Typography variant="h6" gutterBottom>
            메뉴
          </Typography>
          <Divider />
          <List>
            {menuItems.map((item, index) => (
              <ListItem
                button
                key={index}
                onClick={() => {
                  item.action()
                  setDrawerOpen(false)
                }}
              >
                <ListItemIcon>{item.icon}</ListItemIcon>
                <ListItemText primary={item.text} />
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>

      {/* 메인 컨텐츠 */}
      <Container maxWidth="lg" sx={{ mt: 3, mb: 3 }}>
        {loading ? (
          <Box sx={{ textAlign: 'center', py: 8 }}>
            <Typography variant="h6">로딩 중...</Typography>
          </Box>
        ) : (
          <>
            {/* 할 일 추가 폼 */}
            {showAddForm && (
              <AddTaskForm
                categories={categories}
                onTaskCreated={() => {
                  loadData() // 데이터 새로고침
                  setShowAddForm(false) // 폼 숨기기
                }}
              />
            )}

            {/* 필터 및 정렬 바 */}
            <FilterSortBar
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              filterOption={filterOption}
              onFilterChange={setFilterOption}
              selectedPriority={selectedPriority}
              onPriorityChange={setSelectedPriority}
              selectedCategory={selectedCategory}
              onCategoryChange={setSelectedCategory}
              sortOption={sortOption}
              onSortChange={setSortOption}
              categories={availableCategories}
              taskCounts={taskCounts}
            />

            {/* 할 일 목록 */}
            <TaskList
              tasks={filteredAndSortedTasks}
              onTaskUpdate={loadData}
            />
          </>
        )}
      </Container>

      {/* 플로팅 액션 버튼 */}
      <Fab
        color="primary"
        sx={{
          position: 'fixed',
          bottom: 16,
          right: 16,
        }}
        onClick={() => setShowAddForm(!showAddForm)}
      >
        <Add />
      </Fab>
    </Box>
  )
}