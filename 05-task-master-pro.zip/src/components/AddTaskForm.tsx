// src/components/AddTaskForm.tsx
// 새로운 할 일을 추가하는 폼 컴포넌트

'use client'

import { useEffect } from 'react'
import { useFormState, useFormStatus } from 'react-dom'
import {
  Card,
  CardContent,
  CardHeader,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Alert,
  Grid,
  CircularProgress,
} from '@mui/material'
import { Add } from '@mui/icons-material'
import { createTask } from '@/lib/actions'
import { Category } from '@/lib/types'

// AddTaskForm 컴포넌트의 props 타입
interface AddTaskFormProps {
  categories: Category[]
  onTaskCreated?: () => void // 할 일 생성 후 콜백
}

// 폼 제출 버튼 컴포넌트 (useFormStatus 사용)
function SubmitButton() {
  const { pending } = useFormStatus()

  return (
    <Button
      type="submit"
      variant="contained"
      startIcon={pending ? <CircularProgress size={20} /> : <Add />}
      disabled={pending}
      fullWidth
      size="large"
    >
      {pending ? '추가 중...' : '할 일 추가'}
    </Button>
  )
}

export function AddTaskForm({ categories, onTaskCreated }: AddTaskFormProps) {
  // useFormState를 사용한 서버 액션 상태 관리
  const [state, formAction] = useFormState(createTask, {
    success: false,
    message: '',
    errors: {}
  })

  // 성공 시 폼 초기화 및 콜백 실행
  useEffect(() => {
    if (state.success) {
      // 폼 초기화
      const form = document.getElementById('add-task-form') as HTMLFormElement
      form?.reset()
      
      // 상위 컴포넌트에 알림
      onTaskCreated?.()
    }
  }, [state.success, onTaskCreated])

  return (
    <Card sx={{ mb: 3 }}>
      <CardHeader
        title="새로운 할 일 추가"
        titleTypographyProps={{ variant: 'h6' }}
      />
      <CardContent>
        <form id="add-task-form" action={formAction}>
          <Grid container spacing={2}>
            {/* 제목 입력 */}
            <Grid item xs={12}>
              <TextField
                name="title"
                label="할 일 제목"
                fullWidth
                required
                placeholder="무엇을 해야 하나요?"
                error={!!state.errors?.title}
                helperText={state.errors?.title?.[0]}
                inputProps={{ maxLength: 100 }}
              />
            </Grid>

            {/* 설명 입력 */}
            <Grid item xs={12}>
              <TextField
                name="description"
                label="상세 설명 (선택사항)"
                fullWidth
                multiline
                rows={3}
                placeholder="추가 정보를 입력하세요..."
                error={!!state.errors?.description}
                helperText={state.errors?.description?.[0]}
                inputProps={{ maxLength: 500 }}
              />
            </Grid>

            {/* 우선순위 선택 */}
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
                <InputLabel>우선순위</InputLabel>
                <Select
                  name="priority"
                  label="우선순위"
                  defaultValue="medium"
                >
                  <MenuItem value="low">낮음</MenuItem>
                  <MenuItem value="medium">보통</MenuItem>
                  <MenuItem value="high">높음</MenuItem>
                </Select>
              </FormControl>
            </Grid>

            {/* 카테고리 선택 */}
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth>
                <InputLabel>카테고리</InputLabel>
                <Select
                  name="category"
                  label="카테고리"
                  defaultValue="general"
                >
                  <MenuItem value="general">일반</MenuItem>
                  {categories.map((category) => (
                    <MenuItem key={category.id} value={category.name}>
                      {category.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            {/* 마감일 선택 */}
            <Grid item xs={12} sm={4}>
              <TextField
                name="dueDate"
                label="마감일"
                type="date"
                fullWidth
                InputLabelProps={{
                  shrink: true,
                }}
                inputProps={{
                  min: new Date().toISOString().split('T')[0], // 오늘 이후만 선택 가능
                }}
              />
            </Grid>

            {/* 제출 버튼 */}
            <Grid item xs={12}>
              <SubmitButton />
            </Grid>
          </Grid>

          {/* 성공/오류 메시지 */}
          {state.message && (
            <Box sx={{ mt: 2 }}>
              <Alert 
                severity={state.success ? 'success' : 'error'}
                onClose={() => {
                  // 메시지 클리어는 자동으로 처리됨
                }}
              >
                {state.message}
              </Alert>
            </Box>
          )}
        </form>
      </CardContent>
    </Card>
  )
}