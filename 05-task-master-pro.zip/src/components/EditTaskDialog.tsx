// src/components/EditTaskDialog.tsx
// 할 일을 수정하는 다이얼로그 컴포넌트

'use client'

import { useEffect, useState } from 'react'
import { useFormState, useFormStatus } from 'react-dom'
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Alert,
  Grid,
  CircularProgress,
  FormControlLabel,
  Switch,
} from '@mui/material'
import { Save, Close } from '@mui/icons-material'
import { updateTask } from '@/lib/actions'
import { Task } from '@/lib/types'

// EditTaskDialog 컴포넌트의 props 타입
interface EditTaskDialogProps {
  task: Task
  open: boolean
  onClose: () => void
  onTaskUpdate?: () => void
}

// 저장 버튼 컴포넌트 (useFormStatus 사용)
function SaveButton() {
  const { pending } = useFormStatus()

  return (
    <Button
      type="submit"
      variant="contained"
      startIcon={pending ? <CircularProgress size={20} color="inherit" /> : <Save />}
      disabled={pending}
    >
      {pending ? '저장 중...' : '저장'}
    </Button>
  )
}

export function EditTaskDialog({ task, open, onClose, onTaskUpdate }: EditTaskDialogProps) {
  // 로컬 상태로 폼 데이터 관리
  const [formData, setFormData] = useState({
    title: task.title,
    description: task.description || '',
    priority: task.priority,
    category: task.category,
    dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : '',
    completed: task.completed,
  })

  // useFormState를 사용한 서버 액션 상태 관리
  const [state, formAction] = useFormState(updateTask, {
    success: false,
    message: '',
    errors: {}
  })

  // task가 변경되면 폼 데이터 업데이트
  useEffect(() => {
    setFormData({
      title: task.title,
      description: task.description || '',
      priority: task.priority,
      category: task.category,
      dueDate: task.dueDate ? new Date(task.dueDate).toISOString().split('T')[0] : '',
      completed: task.completed,
    })
  }, [task])

  // 성공 시 다이얼로그 닫기
  useEffect(() => {
    if (state.success) {
      onClose()
      onTaskUpdate?.()
    }
  }, [state.success, onClose, onTaskUpdate])

  // 폼 데이터 변경 핸들러
  const handleChange = (field: string) => (event: any) => {
    const value = event.target.type === 'checkbox' ? event.target.checked : event.target.value
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        component: 'form',
        action: formAction,
      }}
    >
      <DialogTitle>할 일 수정</DialogTitle>
      
      <DialogContent>
        {/* 숨겨진 ID 필드 */}
        <input type="hidden" name="id" value={task.id} />
        <input type="hidden" name="completed" value={formData.completed.toString()} />

        <Grid container spacing={2} sx={{ mt: 1 }}>
          {/* 제목 입력 */}
          <Grid item xs={12}>
            <TextField
              name="title"
              label="할 일 제목"
              fullWidth
              required
              value={formData.title}
              onChange={handleChange('title')}
              error={!!state.errors?.title}
              helperText={state.errors?.title?.[0]}
              inputProps={{ maxLength: 100 }}
            />
          </Grid>

          {/* 설명 입력 */}
          <Grid item xs={12}>
            <TextField
              name="description"
              label="상세 설명"
              fullWidth
              multiline
              rows={3}
              value={formData.description}
              onChange={handleChange('description')}
              error={!!state.errors?.description}
              helperText={state.errors?.description?.[0]}
              inputProps={{ maxLength: 500 }}
            />
          </Grid>

          {/* 완료 상태 토글 */}
          <Grid item xs={12}>
            <FormControlLabel
              control={
                <Switch
                  checked={formData.completed}
                  onChange={handleChange('completed')}
                  color="primary"
                />
              }
              label={formData.completed ? '완료됨' : '미완료'}
            />
          </Grid>

          {/* 우선순위 선택 */}
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel>우선순위</InputLabel>
              <Select
                name="priority"
                label="우선순위"
                value={formData.priority}
                onChange={handleChange('priority')}
              >
                <MenuItem value="low">낮음</MenuItem>
                <MenuItem value="medium">보통</MenuItem>
                <MenuItem value="high">높음</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {/* 카테고리 선택 */}
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel>카테고리</InputLabel>
              <Select
                name="category"
                label="카테고리"
                value={formData.category}
                onChange={handleChange('category')}
              >
                <MenuItem value="general">일반</MenuItem>
                <MenuItem value="work">업무</MenuItem>
                <MenuItem value="personal">개인</MenuItem>
                <MenuItem value="shopping">쇼핑</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {/* 마감일 선택 */}
          <Grid item xs={12}>
            <TextField
              name="dueDate"
              label="마감일"
              type="date"
              fullWidth
              value={formData.dueDate}
              onChange={handleChange('dueDate')}
              InputLabelProps={{
                shrink: true,
              }}
            />
          </Grid>
        </Grid>

        {/* 오류 메시지 */}
        {state.message && !state.success && (
          <Box sx={{ mt: 2 }}>
            <Alert severity="error">
              {state.message}
            </Alert>
          </Box>
        )}
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose} startIcon={<Close />}>
          취소
        </Button>
        <SaveButton />
      </DialogActions>
    </Dialog>
  )
}