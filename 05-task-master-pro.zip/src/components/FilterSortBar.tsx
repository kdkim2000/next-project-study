// src/components/FilterSortBar.tsx
// 할 일 목록의 필터링과 정렬을 담당하는 컴포넌트

'use client'

import {
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  TextField,
  InputAdornment,
  Paper,
  Typography,
} from '@mui/material'
import {
  Search,
  FilterList,
  Sort,
} from '@mui/icons-material'
import { FilterOption, SortOption, Priority } from '@/lib/types'

// FilterSortBar 컴포넌트의 props 타입
interface FilterSortBarProps {
  // 필터 관련
  searchTerm: string
  onSearchChange: (search: string) => void
  
  filterOption: FilterOption
  onFilterChange: (filter: FilterOption) => void
  
  selectedPriority: Priority | 'all'
  onPriorityChange: (priority: Priority | 'all') => void
  
  selectedCategory: string
  onCategoryChange: (category: string) => void
  
  // 정렬 관련
  sortOption: SortOption
  onSortChange: (sort: SortOption) => void
  
  // 데이터
  categories: string[]
  taskCounts: {
    total: number
    active: number
    completed: number
  }
}

export function FilterSortBar({
  searchTerm,
  onSearchChange,
  filterOption,
  onFilterChange,
  selectedPriority,
  onPriorityChange,
  selectedCategory,
  onCategoryChange,
  sortOption,
  onSortChange,
  categories,
  taskCounts,
}: FilterSortBarProps) {
  
  // 필터 옵션 라벨
  const filterLabels = {
    all: `전체 (${taskCounts.total})`,
    active: `진행중 (${taskCounts.active})`,
    completed: `완료 (${taskCounts.completed})`,
  }

  // 우선순위 라벨
  const priorityLabels = {
    all: '모든 우선순위',
    low: '낮음',
    medium: '보통',
    high: '높음',
  }

  // 정렬 옵션 라벨
  const sortLabels = {
    createdAt: '생성일순',
    dueDate: '마감일순',
    priority: '우선순위순',
    alphabetical: '가나다순',
  }

  return (
    <Paper
      elevation={1}
      sx={{
        p: 2,
        mb: 3,
        backgroundColor: 'background.paper',
      }}
    >
      {/* 헤더 */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <FilterList sx={{ mr: 1, color: 'primary.main' }} />
        <Typography variant="h6" color="primary">
          필터 & 정렬
        </Typography>
      </Box>

      {/* 검색바 */}
      <Box sx={{ mb: 2 }}>
        <TextField
          fullWidth
          placeholder="할 일 검색..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Search color="action" />
              </InputAdornment>
            ),
          }}
          size="small"
        />
      </Box>

      {/* 필터 및 정렬 옵션들 */}
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: {
            xs: '1fr', // 모바일: 1열
            sm: '1fr 1fr', // 태블릿: 2열
            md: '1fr 1fr 1fr 1fr', // 데스크톱: 4열
          },
          gap: 2,
        }}
      >
        {/* 상태 필터 */}
        <FormControl size="small">
          <InputLabel>상태</InputLabel>
          <Select
            value={filterOption}
            label="상태"
            onChange={(e) => onFilterChange(e.target.value as FilterOption)}
          >
            {Object.entries(filterLabels).map(([value, label]) => (
              <MenuItem key={value} value={value}>
                {label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        {/* 우선순위 필터 */}
        <FormControl size="small">
          <InputLabel>우선순위</InputLabel>
          <Select
            value={selectedPriority}
            label="우선순위"
            onChange={(e) => onPriorityChange(e.target.value as Priority | 'all')}
          >
            {Object.entries(priorityLabels).map(([value, label]) => (
              <MenuItem key={value} value={value}>
                {label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        {/* 카테고리 필터 */}
        <FormControl size="small">
          <InputLabel>카테고리</InputLabel>
          <Select
            value={selectedCategory}
            label="카테고리"
            onChange={(e) => onCategoryChange(e.target.value)}
          >
            <MenuItem value="all">모든 카테고리</MenuItem>
            {categories.map((category) => (
              <MenuItem key={category} value={category}>
                {category}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        {/* 정렬 옵션 */}
        <FormControl size="small">
          <InputLabel>정렬</InputLabel>
          <Select
            value={sortOption}
            label="정렬"
            onChange={(e) => onSortChange(e.target.value as SortOption)}
            startAdornment={
              <InputAdornment position="start">
                <Sort fontSize="small" />
              </InputAdornment>
            }
          >
            {Object.entries(sortLabels).map(([value, label]) => (
              <MenuItem key={value} value={value}>
                {label}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      {/* 활성 필터 표시 */}
      <Box sx={{ display: 'flex', gap: 1, mt: 2, flexWrap: 'wrap' }}>
        {searchTerm && (
          <Chip
            label={`검색: "${searchTerm}"`}
            onDelete={() => onSearchChange('')}
            size="small"
            color="primary"
            variant="outlined"
          />
        )}
        
        {filterOption !== 'all' && (
          <Chip
            label={filterLabels[filterOption]}
            onDelete={() => onFilterChange('all')}
            size="small"
            color="primary"
            variant="outlined"
          />
        )}
        
        {selectedPriority !== 'all' && (
          <Chip
            label={`우선순위: ${priorityLabels[selectedPriority]}`}
            onDelete={() => onPriorityChange('all')}
            size="small"
            color="primary"
            variant="outlined"
          />
        )}
        
        {selectedCategory !== 'all' && (
          <Chip
            label={`카테고리: ${selectedCategory}`}
            onDelete={() => onCategoryChange('all')}
            size="small"
            color="primary"
            variant="outlined"
          />
        )}
      </Box>
    </Paper>
  )
}