// src/components/TaskItem.tsx
// 개별 할 일 항목을 표시하고 관리하는 컴포넌트

'use client'

import { useState, useOptimistic } from 'react'
import { useSortable } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import {
  Card,
  CardContent,
  Checkbox,
  Typography,
  Chip,
  IconButton,
  Box,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
} from '@mui/material'
import {
  DragIndicator,
  MoreVert,
  Edit,
  Delete,
  CalendarToday,
} from '@mui/icons-material'
import { Task } from '@/lib/types'
import { toggleTaskCompletion, deleteTask } from '@/lib/actions'
import { priorityColors } from '@/lib/theme'
import { EditTaskDialog } from './EditTaskDialog'

// TaskItem 컴포넌트의 props 타입
interface TaskItemProps {
  task: Task
  onTaskUpdate?: () => void
}

export function TaskItem({ task, onTaskUpdate }: TaskItemProps) {
  // 드래그 앤 드롭을 위한 sortable 훅
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: task.id })

  // 컴포넌트 로컬 상태
  const [menuAnchor, setMenuAnchor] = useState<null | HTMLElement>(null)
  const [editDialogOpen, setEditDialogOpen] = useState(false)

  // Optimistic UI를 위한 상태 (체크박스 즉시 반영)
  const [optimisticCompleted, setOptimisticCompleted] = useOptimistic(
    task.completed,
    (currentState, newState: boolean) => newState
  )

  // 드래그 중 스타일 적용
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  // 메뉴 열기/닫기
  const handleMenuOpen = (event: React.MouseEvent<HTMLButtonElement>) => {
    setMenuAnchor(event.currentTarget)
  }

  const handleMenuClose = () => {
    setMenuAnchor(null)
  }

  // 체크박스 토글 (Optimistic UI)
  const handleToggleCompletion = async () => {
    const newCompleted = !optimisticCompleted
    
    // 즉시 UI 업데이트
    setOptimisticCompleted(newCompleted)

    try {
      const result = await toggleTaskCompletion(task.id, newCompleted)
      if (result.success) {
        onTaskUpdate?.()
      } else {
        // 실패 시 원래 상태로 되돌리기
        setOptimisticCompleted(task.completed)
        console.error('상태 변경 실패:', result.message)
      }
    } catch (error) {
      console.error('체크박스 토글 오류:', error)
      setOptimisticCompleted(task.completed)
    }
  }

  // 할 일 삭제
  const handleDelete = async () => {
    handleMenuClose()
    
    if (window.confirm('정말로 이 할 일을 삭제하시겠습니까?')) {
      try {
        const result = await deleteTask(task.id)
        if (result.success) {
          onTaskUpdate?.()
        } else {
          alert(result.message)
        }
      } catch (error) {
        console.error('삭제 오류:', error)
        alert('삭제 중 오류가 발생했습니다')
      }
    }
  }

  // 마감일 포맷팅
  const formatDueDate = (dueDate: Date | null) => {
    if (!dueDate) return null
    
    const today = new Date()
    const due = new Date(dueDate)
    const diffDays = Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    
    if (diffDays < 0) return '기한 초과'
    if (diffDays === 0) return '오늘'
    if (diffDays === 1) return '내일'
    return `${diffDays}일 후`
  }

  // 우선순위 라벨
  const priorityLabels = {
    low: '낮음',
    medium: '보통',
    high: '높음',
  }

  return (
    <>
      <Card
        ref={setNodeRef}
        style={style}
        sx={{
          cursor: isDragging ? 'grabbing' : 'default',
          backgroundColor: optimisticCompleted ? 'action.hover' : 'background.paper',
        }}
      >
        <CardContent sx={{ '&:last-child': { pb: 2 } }}>
          <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 2 }}>
            {/* 드래그 핸들 */}
            <IconButton
              size="small"
              sx={{ cursor: 'grab', mt: -0.5 }}
              {...attributes}
              {...listeners}
            >
              <DragIndicator />
            </IconButton>

            {/* 완료 체크박스 */}
            <Checkbox
              checked={optimisticCompleted}
              onChange={handleToggleCompletion}
              sx={{ mt: -1 }}
            />

            {/* 할 일 내용 */}
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography
                variant="h6"
                sx={{
                  textDecoration: optimisticCompleted ? 'line-through' : 'none',
                  opacity: optimisticCompleted ? 0.6 : 1,
                  wordBreak: 'break-word',
                }}
              >
                {task.title}
              </Typography>

              {task.description && (
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{
                    mt: 0.5,
                    opacity: optimisticCompleted ? 0.6 : 1,
                    wordBreak: 'break-word',
                  }}
                >
                  {task.description}
                </Typography>
              )}

              {/* 메타 정보 (우선순위, 카테고리, 마감일) */}
              <Box sx={{ display: 'flex', gap: 1, mt: 1, flexWrap: 'wrap' }}>
                <Chip
                  label={priorityLabels[task.priority]}
                  size="small"
                  sx={{
                    backgroundColor: priorityColors[task.priority],
                    color: 'white',
                    opacity: optimisticCompleted ? 0.6 : 1,
                  }}
                />

                <Chip
                  label={task.category}
                  size="small"
                  variant="outlined"
                  sx={{ opacity: optimisticCompleted ? 0.6 : 1 }}
                />

                {task.dueDate && (
                  <Chip
                    icon={<CalendarToday />}
                    label={formatDueDate(task.dueDate)}
                    size="small"
                    variant="outlined"
                    color={
                      formatDueDate(task.dueDate) === '기한 초과' ? 'error' :
                      formatDueDate(task.dueDate) === '오늘' ? 'warning' : 'default'
                    }
                    sx={{ opacity: optimisticCompleted ? 0.6 : 1 }}
                  />
                )}
              </Box>
            </Box>

            {/* 더보기 메뉴 */}
            <IconButton
              size="small"
              onClick={handleMenuOpen}
              sx={{ mt: -0.5 }}
            >
              <MoreVert />
            </IconButton>
          </Box>
        </CardContent>
      </Card>

      {/* 컨텍스트 메뉴 */}
      <Menu
        anchorEl={menuAnchor}
        open={Boolean(menuAnchor)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={() => {
          handleMenuClose()
          setEditDialogOpen(true)
        }}>
          <ListItemIcon>
            <Edit fontSize="small" />
          </ListItemIcon>
          <ListItemText>수정</ListItemText>
        </MenuItem>
        
        <MenuItem onClick={handleDelete}>
          <ListItemIcon>
            <Delete fontSize="small" />
          </ListItemIcon>
          <ListItemText>삭제</ListItemText>
        </MenuItem>
      </Menu>

      {/* 수정 다이얼로그 */}
      <EditTaskDialog
        task={task}
        open={editDialogOpen}
        onClose={() => setEditDialogOpen(false)}
        onTaskUpdate={onTaskUpdate}
      />
    </>
  )
}