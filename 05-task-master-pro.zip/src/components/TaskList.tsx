// src/components/TaskList.tsx
// 할 일 목록을 표시하고 드래그 앤 드롭 기능을 제공하는 컴포넌트

'use client'

import { useState } from 'react'
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core'
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable'
import {
  Box,
  Typography,
  Alert,
  Snackbar,
} from '@mui/material'
import { Task } from '@/lib/types'
import { TaskItem } from './TaskItem'
import { reorderTasks } from '@/lib/actions'

// TaskList 컴포넌트의 props 타입
interface TaskListProps {
  tasks: Task[]
  onTaskUpdate?: () => void // 할 일 업데이트 후 콜백
}

export function TaskList({ tasks, onTaskUpdate }: TaskListProps) {
  // 로컬 상태로 할 일 목록 관리 (드래그 중 즉시 반영용)
  const [localTasks, setLocalTasks] = useState(tasks)
  const [snackbarOpen, setSnackbarOpen] = useState(false)
  const [snackbarMessage, setSnackbarMessage] = useState('')
  const [snackbarSeverity, setSnackbarSeverity] = useState<'success' | 'error'>('success')

  // 드래그 앤 드롭 센서 설정
  const sensors = useSensors(
    useSensor(PointerSensor), // 마우스/터치 드래그
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates, // 키보드 접근성
    })
  )

  // 드래그 종료 시 실행되는 함수
  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event

    // 드래그된 항목이 다른 위치에 놓였을 때만 처리
    if (over && active.id !== over.id) {
      const oldIndex = localTasks.findIndex(task => task.id === active.id)
      const newIndex = localTasks.findIndex(task => task.id === over.id)

      // 즉시 UI 업데이트 (Optimistic UI)
      const reorderedTasks = arrayMove(localTasks, oldIndex, newIndex)
      setLocalTasks(reorderedTasks)

      try {
        // 새로운 순서를 서버에 저장
        const newOrder = reorderedTasks.map((task, index) => ({
          id: task.id,
          order: index + 1
        }))

        const result = await reorderTasks(newOrder)

        if (result.success) {
          setSnackbarMessage(result.message || '순서가 변경되었습니다')
          setSnackbarSeverity('success')
          setSnackbarOpen(true)
          onTaskUpdate?.() // 상위 컴포넌트에 변경 알림
        } else {
          throw new Error(result.message)
        }
      } catch (error) {
        console.error('순서 변경 오류:', error)
        // 오류 발생 시 원래 순서로 되돌리기
        setLocalTasks(tasks)
        setSnackbarMessage('순서 변경 중 오류가 발생했습니다')
        setSnackbarSeverity('error')
        setSnackbarOpen(true)
      }
    }
  }

  // 할 일이 없을 때 표시할 메시지
  if (localTasks.length === 0) {
    return (
      <Box
        sx={{
          textAlign: 'center',
          py: 8,
          color: 'text.secondary'
        }}
      >
        <Typography variant="h6" gutterBottom>
          📝 할 일이 없습니다
        </Typography>
        <Typography variant="body2">
          새로운 할 일을 추가해보세요!
        </Typography>
      </Box>
    )
  }

  return (
    <>
      {/* 드래그 앤 드롭 컨텍스트 */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        {/* 정렬 가능한 컨텍스트 */}
        <SortableContext
          items={localTasks.map(task => task.id)}
          strategy={verticalListSortingStrategy}
        >
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {localTasks.map((task) => (
              <TaskItem
                key={task.id}
                task={task}
                onTaskUpdate={onTaskUpdate}
              />
            ))}
          </Box>
        </SortableContext>
      </DndContext>

      {/* 피드백 스낵바 */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={() => setSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={() => setSnackbarOpen(false)}
          severity={snackbarSeverity}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </>
  )
}