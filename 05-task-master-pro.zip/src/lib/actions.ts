// src/lib/actions.ts
// Next.js Server Actions - 서버에서 실행되는 함수들

'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { prisma } from './prisma'
import {
  createTaskSchema,
  updateTaskSchema,
  reorderTasksSchema,
  createCategorySchema,
  type FormState
} from './types'

// 할 일 생성 액션
export async function createTask(prevState: FormState, formData: FormData): Promise<FormState> {
  try {
    // 폼 데이터를 객체로 변환
    const rawData = {
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      priority: formData.get('priority') as string,
      category: formData.get('category') as string,
      dueDate: formData.get('dueDate') as string,
    }

    // Zod로 데이터 유효성 검사
    const validatedData = createTaskSchema.parse(rawData)

    // 현재 최대 order 값 조회 후 +1
    const maxOrder = await prisma.task.aggregate({
      _max: { order: true }
    })
    const newOrder = (maxOrder._max.order || 0) + 1

    // 데이터베이스에 할 일 저장
    await prisma.task.create({
      data: {
        ...validatedData,
        order: newOrder
      }
    })

    // 캐시 재검증 (화면 새로고침 효과)
    revalidatePath('/')

    return {
      success: true,
      message: '할 일이 성공적으로 추가되었습니다!'
    }

  } catch (error) {
    console.error('할 일 생성 오류:', error)

    // Zod 유효성 검사 오류 처리
    if (error instanceof Error && 'issues' in error) {
      const zodError = error as any
      const fieldErrors: Record<string, string[]> = {}
      
      zodError.issues.forEach((issue: any) => {
        const field = issue.path[0]
        if (!fieldErrors[field]) {
          fieldErrors[field] = []
        }
        fieldErrors[field].push(issue.message)
      })

      return {
        success: false,
        message: '입력값을 확인해주세요',
        errors: fieldErrors
      }
    }

    return {
      success: false,
      message: '할 일 추가 중 오류가 발생했습니다'
    }
  }
}

// 할 일 수정 액션
export async function updateTask(prevState: FormState, formData: FormData): Promise<FormState> {
  try {
    const rawData = {
      id: formData.get('id') as string,
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      priority: formData.get('priority') as string,
      category: formData.get('category') as string,
      dueDate: formData.get('dueDate') as string,
      completed: formData.get('completed') === 'true'
    }

    const validatedData = updateTaskSchema.parse(rawData)

    await prisma.task.update({
      where: { id: validatedData.id },
      data: {
        title: validatedData.title,
        description: validatedData.description,
        priority: validatedData.priority,
        category: validatedData.category,
        dueDate: validatedData.dueDate,
        completed: validatedData.completed
      }
    })

    revalidatePath('/')

    return {
      success: true,
      message: '할 일이 성공적으로 수정되었습니다!'
    }

  } catch (error) {
    console.error('할 일 수정 오류:', error)
    return {
      success: false,
      message: '할 일 수정 중 오류가 발생했습니다'
    }
  }
}

// 할 일 삭제 액션
export async function deleteTask(taskId: string) {
  try {
    await prisma.task.delete({
      where: { id: taskId }
    })

    revalidatePath('/')

    return {
      success: true,
      message: '할 일이 삭제되었습니다'
    }

  } catch (error) {
    console.error('할 일 삭제 오류:', error)
    return {
      success: false,
      message: '할 일 삭제 중 오류가 발생했습니다'
    }
  }
}

// 할 일 완료 상태 토글 액션
export async function toggleTaskCompletion(taskId: string, completed: boolean) {
  try {
    await prisma.task.update({
      where: { id: taskId },
      data: { completed }
    })

    revalidatePath('/')

    return {
      success: true,
      message: completed ? '할 일을 완료했습니다!' : '할 일을 미완료로 변경했습니다'
    }

  } catch (error) {
    console.error('할 일 상태 변경 오류:', error)
    return {
      success: false,
      message: '상태 변경 중 오류가 발생했습니다'
    }
  }
}

// 할 일 순서 변경 액션 (드래그 앤 드롭용)
export async function reorderTasks(newOrder: { id: string; order: number }[]) {
  try {
    // 트랜잭션으로 모든 순서를 한 번에 업데이트
    await prisma.$transaction(
      newOrder.map(({ id, order }) =>
        prisma.task.update({
          where: { id },
          data: { order }
        })
      )
    )

    revalidatePath('/')

    return {
      success: true,
      message: '순서가 변경되었습니다'
    }

  } catch (error) {
    console.error('순서 변경 오류:', error)
    return {
      success: false,
      message: '순서 변경 중 오류가 발생했습니다'
    }
  }
}

// 카테고리 생성 액션
export async function createCategory(prevState: FormState, formData: FormData): Promise<FormState> {
  try {
    const rawData = {
      name: formData.get('name') as string,
      color: formData.get('color') as string,
    }

    const validatedData = createCategorySchema.parse(rawData)

    await prisma.category.create({
      data: validatedData
    })

    revalidatePath('/')

    return {
      success: true,
      message: '카테고리가 추가되었습니다!'
    }

  } catch (error) {
    console.error('카테고리 생성 오류:', error)
    return {
      success: false,
      message: '카테고리 추가 중 오류가 발생했습니다'
    }
  }
}