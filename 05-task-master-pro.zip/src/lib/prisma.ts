// src/lib/prisma.ts
// Prisma 클라이언트 설정 및 싱글톤 패턴 적용

import { PrismaClient } from '@prisma/client'

// 전역 타입 선언 (개발 환경에서 Hot Reload 시 중복 인스턴스 방지)
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Prisma 클라이언트 인스턴스 생성
// 개발 환경에서는 전역 변수를 사용하여 Hot Reload 시에도 연결 유지
export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    // 개발 환경에서 쿼리 로그 출력
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  })

// 개발 환경에서만 전역 변수에 저장
if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma