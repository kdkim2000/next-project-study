// src/lib/theme.ts
// Material-UI 테마 설정

'use client'

import { createTheme } from '@mui/material/styles'

// 커스텀 테마 생성
export const theme = createTheme({
  // 색상 팔레트 설정
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2', // 메인 블루 색상
      light: '#42a5f5',
      dark: '#1565c0',
    },
    secondary: {
      main: '#dc004e', // 액센트 색상
    },
    success: {
      main: '#4caf50', // 완료 상태 색상
    },
    warning: {
      main: '#ff9800', // 중요도 중간 색상
    },
    error: {
      main: '#f44336', // 중요도 높음 색상
    },
    background: {
      default: '#fafafa', // 배경 색상
      paper: '#ffffff',
    },
  },
  
  // 타이포그래피 설정
  typography: {
    fontFamily: 'Inter, "Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
      fontSize: '2.125rem',
    },
    h5: {
      fontWeight: 600,
      fontSize: '1.5rem',
    },
    h6: {
      fontWeight: 600,
      fontSize: '1.25rem',
    },
    subtitle1: {
      fontWeight: 500,
    },
    body1: {
      fontSize: '1rem',
      lineHeight: 1.6,
    },
    body2: {
      fontSize: '0.875rem',
      lineHeight: 1.5,
    },
  },
  
  // 컴포넌트 기본 속성 설정
  components: {
    // 버튼 컴포넌트 설정
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none', // 텍스트 대문자 변환 비활성화
          borderRadius: 8,
          fontWeight: 500,
        },
      },
    },
    
    // 카드 컴포넌트 설정
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          transition: 'box-shadow 0.2s ease-in-out',
          '&:hover': {
            boxShadow: '0 4px 16px rgba(0,0,0,0.15)',
          },
        },
      },
    },
    
    // 텍스트 필드 설정
    MuiTextField: {
      defaultProps: {
        variant: 'outlined',
        size: 'medium',
      },
      styleOverrides: {
        root: {
          '& .MuiOutlinedInput-root': {
            borderRadius: 8,
          },
        },
      },
    },
    
    // 칩 컴포넌트 설정
    MuiChip: {
      styleOverrides: {
        root: {
          borderRadius: 6,
          fontWeight: 500,
        },
      },
    },
  },
  
  // 공간 설정 (8px 기본 단위)
  spacing: 8,
})

// 우선순위별 색상 매핑
export const priorityColors = {
  low: theme.palette.success.main,
  medium: theme.palette.warning.main,
  high: theme.palette.error.main,
} as const

// 카테고리 기본 색상들
export const categoryColors = [
  '#1976d2', // 파랑
  '#388e3c', // 초록
  '#f57c00', // 주황
  '#7b1fa2', // 보라
  '#d32f2f', // 빨강
  '#0097a7', // 청록
  '#616161', // 회색
] as const