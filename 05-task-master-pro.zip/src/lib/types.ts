// src/lib/types.ts
// 애플리케이션에서 사용하는 타입 정의와 Zod 스키마

import { z } from 'zod'

// 우선순위 타입
export type Priority = 'low' | 'medium' | 'high'

// 필터 옵션 타입
export type FilterOption = 'all' | 'active' | 'completed'

// 정렬 옵션 타입
export type SortOption = 'createdAt' | 'dueDate' | 'priority' | 'alphabetical'

// 할 일 생성을 위한 Zod 스키마
export const createTaskSchema = z.object({
  title: z.string()
    .min(1, '제목을 입력해주세요')
    .max(100, '제목은 100자 이하로 입력해주세요'),
  description: z.string()
    .max(500, '설명은 500자 이하로 입력해주세요')
    .optional(),
  priority: z.enum(['low', 'medium', 'high'])
    .default('medium'),
  category: z.string()
    .min(1, '카테고리를 선택해주세요')
    .default('general'),
  dueDate: z.string()
    .optional()
    .transform((val) => val ? new Date(val) : undefined)
})

// 할 일 수정을 위한 Zod 스키마
export const updateTaskSchema = createTaskSchema.extend({
  id: z.string().min(1, 'ID가 필요합니다'),
  completed: z.boolean().optional()
})

// 할 일 순서 변경을 위한 스키마
export const reorderTasksSchema = z.object({
  tasks: z.array(z.object({
    id: z.string(),
    order: z.number()
  }))
})

// 카테고리 생성 스키마
export const createCategorySchema = z.object({
  name: z.string()
    .min(1, '카테고리명을 입력해주세요')
    .max(30, '카테고리명은 30자 이하로 입력해주세요'),
  color: z.string()
    .regex(/^#[0-9A-F]{6}$/i, '올바른 색상 코드를 입력해주세요')
    .default('#1976d2')
})

// 폼 상태 타입 (useFormState용)
export interface FormState {
  success?: boolean
  message?: string
  errors?: Record<string, string[]>
}

// 할 일 항목 타입 (Prisma 모델과 동일)
export interface Task {
  id: string
  title: string
  description: string | null
  completed: boolean
  priority: Priority
  category: string
  dueDate: Date | null
  createdAt: Date
  updatedAt: Date
  order: number
}

// 카테고리 타입
export interface Category {
  id: string
  name: string
  color: string
}